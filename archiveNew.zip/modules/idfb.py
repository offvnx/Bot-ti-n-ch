from zlapi.models import Message
import requests
import os

des = {
    'version': "1.0.0",
    'credits': "Hoàng Duy Tư",
    'description': "Lấy thông tin Facebook từ link hoặc ID"
}

def get_facebook_info(url):
    api_url = "https://offvnx.x10.bz/api/convertID.php?url=" + requests.utils.quote(url)
    try:
        response = requests.get(api_url, timeout=10)
        data = response.json()
        return {
            'id': data.get('id'),
            'name': data.get('name')
        }
    except Exception:
        return None

def handle_idfb_command(message, message_object, thread_id, thread_type, author_id, client):
    if not hasattr(message_object, 'content') or not isinstance(message_object.content, str):
        return

    if not message_object.content.startswith('/idfb'):
        return

    parts = message.strip().split(" ", 1)
    if len(parts) < 2:
        client.send(
            Message(text="❌ Vui lòng nhập đúng định dạng: /idfb [link hoặc id]"),
            thread_id=thread_id,
            thread_type=thread_type
        )
        return

    parameter = parts[1].strip()
    facebook_id = parameter if parameter.isdigit() else None
    facebook_name = None

    if not facebook_id:
        if "facebook.com" not in parameter:
            client.send(
                Message(text="❌ Liên kết không hợp lệ."),
                thread_id=thread_id,
                thread_type=thread_type
            )
            return

        fb_info = get_facebook_info(parameter)
        if not fb_info or not fb_info.get('id'):
            client.send(
                Message(text="❌ Không thể lấy ID từ liên kết Facebook."),
                thread_id=thread_id,
                thread_type=thread_type
            )
            return
        facebook_id = fb_info.get('id')
        facebook_name = fb_info.get('name')
    else:
        facebook_name = "Không lấy được"

    avatar_url = f"https://graph.facebook.com/{facebook_id}/picture?width=1500&height=1500&access_token=2712477385668128|b429aeb53369951d411e1cae8e810640"

    caption = (
        f"UID Facebook: {facebook_id}\n"
        f"Họ tên Facebook: {facebook_name or 'Không lấy được'}\n"
        f"Link Facebook: https://www.facebook.com/profile.php?id={facebook_id}"
    )

    try:
        img = requests.get(avatar_url, timeout=5).content
        path = "fb_avatar.jpg"
        with open(path, "wb") as f:
            f.write(img)
        client.sendLocalImage(
            path,
            message=Message(text=caption),
            thread_id=thread_id,
            thread_type=thread_type
        )
        os.remove(path)
    except Exception:
        client.send(Message(text=caption), thread_id=thread_id, thread_type=thread_type)

def get_szl():
    return {
        'idfb': handle_idfb_command,
        # các lệnh khác nếu có
    }