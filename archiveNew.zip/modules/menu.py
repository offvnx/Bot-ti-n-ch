import os
import random
import pytz
import colorsys
import requests
from datetime import datetime
from PIL import Image, ImageDraw, ImageFont, ImageFilter

from zlapi.models import Message, Mention

BOT_START_TIME = datetime.now()

def get_bot_uptime():
    now = datetime.now()
    delta = now - BOT_START_TIME
    days = delta.days
    hours, rem = divmod(delta.seconds, 3600)
    minutes, seconds = divmod(rem, 60)
    return f"{days} Ngày {hours} Giờ {minutes} Phút {seconds} Giây"

des = {
    'version': "1.0.6",
    'credits': "Hoàng Duy Tư",
    'description': "Menu Zalo nâng cấp đẹp, avatar viền cầu vồng, thời gian ngày/đêm"
}

FONT_PATH = "BeVietnamPro-Bold.ttf"
FONT_EMOJI_PATH = "emoji.ttf"
BACKGROUND_FOLDER = "background"
AVATAR_PATH = "modules/cache/user_avatar.png"
SIZE = (1124, 402)
BOX_COLOR = (0, 0, 0, 180)

def download_avatar(avatar_url, save_path=AVATAR_PATH):
    try:
        os.makedirs(os.path.dirname(save_path), exist_ok=True)
        resp = requests.get(avatar_url, stream=True, timeout=10)
        if resp.status_code == 200:
            with open(save_path, "wb") as f:
                for chunk in resp.iter_content(1024):
                    f.write(chunk)
            return save_path
    except Exception as e:
        print(f"Lỗi download_avatar: {e}")
    return None

def get_user_name_by_id(bot, author_id):
    try:
        user_info = bot.fetchUserInfo(author_id).changed_profiles[author_id]
        return user_info.zaloName or user_info.displayName
    except:
        return "Unknown User"

def draw_rainbow_border(size, border_width=12):
    base = Image.new("RGBA", size, (0, 0, 0, 0))
    draw = ImageDraw.Draw(base)
    for i in range(border_width):
        hue = i / border_width
        r, g, b = [int(x * 255) for x in colorsys.hsv_to_rgb(hue, 1, 1)]
        draw.ellipse((i, i, size[0] - i - 1, size[1] - i - 1), outline=(r, g, b, 255), width=1)
    return base

def draw_gradient_text(draw, position, text, font, start_color, end_color):
    if start_color == end_color:
        draw.text(position, text, font=font, fill=start_color)
        return
    x, y = position
    gradient = [
        (
            int(start_color[0] + (end_color[0] - start_color[0]) * i / len(text)),
            int(start_color[1] + (end_color[1] - start_color[1]) * i / len(text)),
            int(start_color[2] + (end_color[2] - start_color[2]) * i / len(text))
        )
        for i in range(len(text))
    ]
    for i, char in enumerate(text):
        draw.text((x, y), char, font=font, fill=gradient[i])
        x += draw.textlength(char, font=font)

def random_contrast_color(bg_color):
    r, g, b = bg_color[:3]
    luminance = (0.299*r + 0.587*g + 0.114*b)/255
    return (255, 255, 255) if luminance < 0.5 else (0, 0, 0)

def draw_text_with_shadow(draw, position, text, font, fill, shadow_color=(0,0,0), offset=(2,2)):
    x, y = position
    draw.text((x + offset[0], y + offset[1]), text, font=font, fill=shadow_color)
    draw.text((x, y), text, font=font, fill=fill)

def menuzl(message, message_object, thread_id, thread_type, author_id, client):
    try:
        user_name = get_user_name_by_id(client, author_id)
        image_files = [f for f in os.listdir(BACKGROUND_FOLDER) if f.lower().endswith(('.jpg', '.jpeg', '.png'))]
        if not image_files:
            client.send(Message(text="❌ Không tìm thấy hình nền trong thư mục."), thread_id=thread_id, thread_type=thread_type)
            return

        image_path = os.path.join(BACKGROUND_FOLDER, random.choice(image_files))
        output_image_path = "output.jpg"

        bg_image = Image.open(image_path).convert("RGBA").resize(SIZE).filter(ImageFilter.GaussianBlur(6))
        overlay = Image.new("RGBA", SIZE, (0, 0, 0, 0))
        draw = ImageDraw.Draw(overlay)

        box_x1, box_y1 = 50, 30
        box_x2, box_y2 = SIZE[0] - 50, SIZE[1] - 30
        draw.rounded_rectangle([(box_x1, box_y1), (box_x2, box_y2)], radius=35, fill=BOX_COLOR)

        try:
            font_text = ImageFont.truetype(FONT_PATH, 36)
            font_time = ImageFont.truetype(FONT_PATH, 32)
            font_emoji = ImageFont.truetype(FONT_EMOJI_PATH, 32)
        except:
            font_text = font_time = font_emoji = ImageFont.load_default()

        vn_tz = pytz.timezone('Asia/Ho_Chi_Minh')
        now = datetime.now(vn_tz)
        hour = now.hour
        time_icon = "🌤️" if 6 <= hour < 18 else "🌙"
        time_text = now.strftime(" %H:%M")
        time_x = box_x2 - 250
        time_y = box_y1 + 10

        icon_x = time_x - 75
        icon_color = random_contrast_color(BOX_COLOR)
        draw_text_with_shadow(draw, (icon_x, time_y - 8), time_icon, font_emoji, icon_color)
        draw.text((time_x, time_y), time_text, font=font_time, fill=(255, 255, 255))

        date_text = now.strftime("📅 %d/%m/%Y")
        date_w = draw.textbbox((0, 0), date_text, font=font_time)[2]
        date_x = box_x2 - date_w - 40
        date_y = time_y + 40
        draw_gradient_text(draw, (date_x, date_y), date_text, font_time, (255, 215, 0), (255, 215, 0))

        uptime_text = f"            Thời Gian Hoạt Động: {get_bot_uptime()}"
        uptime_font = ImageFont.truetype(FONT_PATH, 30) if os.path.exists(FONT_PATH) else ImageFont.load_default()
        uptime_x = (box_x1 + box_x2) // 2 - draw.textlength(uptime_text, font=uptime_font) // 2
        uptime_y = box_y1 + 90
        draw_gradient_text(draw, (uptime_x, uptime_y), uptime_text, uptime_font, (0, 255, 255), (0, 128, 255))

        avatar_layer = Image.new("RGBA", SIZE, (0, 0, 0, 0))
        try:
            user = client.fetchUserInfo(author_id).changed_profiles[author_id]
            avatar_path = download_avatar(user.avatar)
            if avatar_path:
                avatar_size = (160, 160)
                avatar = Image.open(avatar_path).convert("RGBA").resize(avatar_size)

                mask = Image.new("L", avatar_size, 0)
                ImageDraw.Draw(mask).ellipse((0, 0, *avatar_size), fill=255)
                avatar.putalpha(mask)

                shadow = Image.new("RGBA", (180, 180), (0, 0, 0, 0))
                ImageDraw.Draw(shadow).ellipse((10, 10, 170, 170), fill=(0, 0, 0, 100))

                border = draw_rainbow_border((180, 180), 12)
                x, y = box_x1 + 20, (box_y1 + box_y2) // 2 - avatar_size[1] // 2

                avatar_layer.paste(shadow, (x - 10, y - 10), shadow)
                avatar_layer.paste(border, (x - 10, y - 10), border)
                avatar_layer.paste(avatar, (x, y), avatar)
        except Exception as e:
            print(f"Lỗi avatar: {e}")

        text_lines = [
            f"Xin Chào! {user_name}",
            " ",
            "DƯỚI ĐÂY LÀ DANH SÁCH LỆNH !"
        ]
        for i, line in enumerate(text_lines):
            text_x = (box_x1 + box_x2) // 2 - len(line) * 9
            text_y = uptime_y + 50 + i * 40
            draw_gradient_text(draw, (text_x, text_y), line, font_text, (0, 255, 0), (0, 255, 0))

        final = Image.alpha_composite(bg_image, overlay)
        final = Image.alpha_composite(final, avatar_layer)
        final.convert("RGB").save(output_image_path, "JPEG")

        text = """@member
➜ /scrtool - Tải Full Source Tool
➜ /scrtelegram - Tải Full Source Bot Telegram
➜ /scrzalo - Tải Full Source Bot Zalo
➜ /ff - Xem thông tin nick Free Fire
➜ /mail - Tạo Mail Ảo Lấy Mã
➜ /regfb - Reg Tài Khoản Facebook
➜ /info - Xem Thông Tin Nick Zalo
➜ /tiktok - Tải video không logo Tiktok
➜ /tt - Xem Thông Tin Nick Tiktok
➜ /thoitiet - Xem Thông Tin Thời Tiết
➜ /fb - Xem Thông Tin Nick Facebook
➜ /2fa - Lấy Mã 2FA Facebook
➜ /roblox - Xem Thông Tin Nick Roblox
➜ /ask - ChatGPT
➜ /vdgai - Random Video Gái
➜ /down - Tải video Đa Nền Tảng
➜ /github - Xem Thông Tin Nick Github
➜ /qrbank - Tạo QR Chuyển khoản
➜ /qrcode - Tạo Mã QR Bằng Văn Bản
➜ /spam - SPAM SĐT SMS FREE
➜ /spamvip - SPAM SĐT SMS VIP
➜ /getkey - Lấy Key Free SPAM SĐT SMS
➜ /key - Nhập Key Free SPAM SĐT SMS
➜ /muavip - Mua VIP SPAM SĐT SMS
"""

        client.sendLocalImage(
            imagePath=output_image_path,
            message=Message(text=text, mention=Mention(author_id, offset=0, length=len("@member"))),
            thread_id=thread_id,
            thread_type=thread_type,
            width=SIZE[0],
            height=SIZE[1]
        )

    except Exception as e:
        print(f"[❌] Lỗi hiển thị menu: {e}")
        client.send(Message(text="Đã xảy ra lỗi khi hiển thị menu!"), thread_id=thread_id, thread_type=thread_type)

def get_szl():
    return {'menu': menuzl}