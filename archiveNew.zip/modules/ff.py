import os
from zlapi.models import Message
import requests
import pycountry
from datetime import datetime

des = {
    'version': "1.0.2",
    'credits': "Hoàng Duy Tư",
    'description': "Lấy thông tin Free Fire từ UID"
}

def get_freefire_info(uid):
    url = f"https://info-ob50-gpl.vercel.app/get?uid={uid}"
    try:
        res = requests.get(url, timeout=10)
        if res.status_code == 200:
            return res.json()
    except:
        pass
    return None

def get_country_flag(region_code):
    try:
        country = pycountry.countries.get(alpha_2=region_code.upper())
        if country:
            return chr(127397 + ord(region_code[0])) + chr(127397 + ord(region_code[1]))
    except:
        pass
    return "🏳️"

def format_timestamp(ts):
    try:
        dt = datetime.utcfromtimestamp(int(ts))
        return dt.strftime("%d/%m/%Y %H:%M:%S")
    except:
        return "Không rõ"

def translate_language(lang_code):
    if "VI" in lang_code:
        return "Tiếng Việt"
    elif "EN" in lang_code:
        return "English"
    elif "ES" in lang_code:
        return "Español"
    return "Không rõ"

def format_freefire_info(data):
    basic = data.get("AccountInfo", {})
    profile = data.get("AccountProfileInfo", {})
    clan = data.get("GuildInfo", {})
    captain = data.get("captainBasicInfo", {})
    credit = data.get("creditScoreInfo", {})
    pet = data.get("petInfo", {})
    social = data.get("socialinfo", {})

    uid = basic.get("AccountBPID", "Không rõ")
    name = basic.get("AccountName", "Không rõ")
    level = basic.get("AccountLevel", "?")
    exp = basic.get("AccountEXP", "?")
    region = basic.get("AccountRegion", "??").upper()
    server = f"{get_country_flag(region)} ({region})"
    likes = basic.get("AccountLikes", 0)
    lang = translate_language(social.get("language", ""))
    bio = social.get("signature", "Không có")
    br_rank = basic.get("BrMaxRank", "?")
    br_rp = basic.get("BrRankPoint", "?")
    cs_rank = basic.get("CsMaxRank", "?")
    cs_rp = basic.get("CsRankPoint", "?")
    skills = ", ".join(str(i) for i in profile.get("EquippedSkills", [])) or "Không rõ"
    created = format_timestamp(basic.get("AccountCreateTime", 0)).split(" ")
    last_login = format_timestamp(basic.get("AccountLastLogin", 0)).split(" ")

    lines = []
    lines.append("┌ 👤 THÔNG TIN TÀI KHOẢN")
    lines.append(f"├─ 👑 Tên: {name}")
    lines.append(f"├─ 🆔 UID: {uid}")
    lines.append(f"├─ 📊 Level: {level} (Exp: {exp})")
    lines.append(f"├─ 🌍 Server: {server}")
    lines.append(f"├─ 🈯 Ngôn Ngữ: {lang}")
    lines.append(f"├─ 👍 Likes: {likes}")
    lines.append(f"└─ 📝 Tiểu Sử: {bio}")

    lines.append("┌ 🎮 THÔNG TIN HOẠT ĐỘNG")
    lines.append(f"├─ 🥇 BR Rank: {br_rank}")
    lines.append(f"├─ 🎯 Điểm BR: {br_rp}")
    lines.append(f"├─ 🛡️ CS Rank: {cs_rank} [{cs_rp}⭐️]")
    lines.append(f"├─ 🧠 Kỹ Năng NV: {skills}")
    lines.append(f"├─ 📅 Ngày Tạo Acc: {created[1]} || {created[0]}")
    lines.append(f"└─ 🕒 Đăng Nhập Lần Cuối: {last_login[1]} || {last_login[0]}")

    if pet:
        lines.append("┌ 🐾 THÔNG TIN PET")
        lines.append(f"├─ 🐶 Tên: {pet.get('name', 'Không rõ')}")
        lines.append(f"├─ 🔢 Level: {pet.get('level', '?')} (Exp: {pet.get('exp', '?')})")
        lines.append(f"└─ 🎨 Skin: {pet.get('skinId', 'Không rõ')}")

    if clan:
        lines.append("┌ 🛡️ THÔNG TIN QUÂN ĐOÀN")
        lines.append(f"├─ 🆔 ID: {clan.get('GuildID', 'Không rõ')}")
        lines.append(f"├─ 👥 Tên: {clan.get('GuildName', 'Không rõ')}")
        lines.append(f"├─ 🔰 Level: {clan.get('GuildLevel', '?')}")
        lines.append(f"├─ 👤 Thành Viên: {clan.get('GuildMember', '?')}/{clan.get('GuildCapacity', '?')}")
        lines.append("└─ 👑 Chủ Quân Đoàn:")

        lines.append(f"    ├─ 👑 Tên: {captain.get('nickname', 'Không rõ')}")
        lines.append(f"    ├─ 🆔 UID: {captain.get('accountId', 'Không rõ')}")
        lines.append(f"    ├─ 📊 Level: {captain.get('level', '?')} (Exp: {captain.get('exp', '?')})")
        lines.append(f"    ├─ 🥇 BR: {captain.get('rank', '?')} [{captain.get('rankingPoints', '?')}⭐️]")
        lines.append(f"    ├─ 🛡️ CS: {captain.get('csRank', '?')} [{captain.get('csRankingPoints', '?')}⭐️]")
        c_created = format_timestamp(captain.get("createAt", 0)).split(" ")
        c_login = format_timestamp(captain.get("lastLoginAt", 0)).split(" ")
        lines.append(f"    ├─ 📅 Tạo Acc: {c_created[1]} || {c_created[0]}")
        lines.append(f"    └─ 🕒 Đăng Nhập: {c_login[1]} || {c_login[0]}")

    lines.append(f"\n📦 Phiên Bản: {basic.get('ReleaseVersion', 'Không rõ')}")
    lines.append("📌 Lưu ý: Thông số rank chỉ mang tính tham khảo")
    return "\n".join(lines), uid, region

def download_and_send_image(url, filename, message_text, client, thread_id, thread_type):
    try:
        img = requests.get(url, timeout=10).content
        with open(filename, "wb") as f:
            f.write(img)
        client.sendLocalImage(filename, message=Message(text=message_text), thread_id=thread_id, thread_type=thread_type)
        os.remove(filename)
    except:
        client.send(Message(text=message_text), thread_id=thread_id, thread_type=thread_type)

def handle_ff_command(message, message_object, thread_id, thread_type, author_id, client):
    if not hasattr(message_object, 'content') or not isinstance(message_object.content, str):
        return
    if not message_object.content.startswith('/ff'):
        return

    parts = message_object.content.strip().split(" ", 1)
    if len(parts) < 2:
        client.send(
            Message(text="⚠️ Nhập đúng cú pháp:\n/ff <uid>\nVí dụ: /ff 12345678"),
            thread_id=thread_id,
            thread_type=thread_type
        )
        return

    uid = parts[1].strip()
    data = get_freefire_info(uid)
    if data and "AccountInfo" in data:
        info_text, uid, region = format_freefire_info(data)

        # Gửi ảnh banner
        banner_url = f"https://bngx-bnr-ff.onrender.com/bnr?uid={uid}&region={region}"
        download_and_send_image(banner_url, "banner.jpg", info_text, client, thread_id, thread_type)

        # Gửi ảnh trang phục
        outfit_url = f"https://scromnyi-ff.vercel.app/outfits?region={region}&uid={uid}&key=DevScromnyi"
        try:
            img = requests.get(outfit_url, timeout=10).content
            with open("outfit.jpg", "wb") as f:
                f.write(img)
            client.sendLocalImage("outfit.jpg", message=Message(text="🎽 Trang phục hiện tại:"), thread_id=thread_id, thread_type=thread_type)
            os.remove("outfit.jpg")
        except:
            client.send(Message(text="⚠️ Không thể tải trang phục."), thread_id=thread_id, thread_type=thread_type)
    else:
        client.send(
            Message(text="❌ Không tìm thấy thông tin người chơi."),
            thread_id=thread_id,
            thread_type=thread_type
        )

def get_szl():
    return {
        'ff': handle_ff_command,
    }