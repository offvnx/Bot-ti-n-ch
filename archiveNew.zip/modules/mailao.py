from zlapi.models import Message
import requests

des = {
    'version': "1.0.2",
    'credits': "Hoàng Duy Tư",
    'description': "Tạo và kiểm tra email tạm thời từ hunght1890.com"
}

DEFAULT_DOMAIN = "hunght1890.com"
BASE_URL = "http://hunght1890.com/{}"

def handle_mail_command(message, message_object, thread_id, thread_type, author_id, client):
    args = message.strip().split(" ", 1)

    if len(args) < 2:
        huongdan = (
            "📨 Cách dùng: /mail [tên email]\n"
            "💡 Ví dụ:\n"
            "/mail offvnx\n\n"
            f"📧 Email mặc định: @{DEFAULT_DOMAIN}"
        )
        client.send(Message(text=huongdan), thread_id=thread_id, thread_type=thread_type)
        return

    email_name = args[1].strip()
    email = f"{email_name}@{DEFAULT_DOMAIN}"

    reply = (
        "✅ Đã tạo email tạm thời!\n\n"
        f"📧 Email: {email}\n"
        f"📥 Kiểm tra hộp thư bằng lệnh:\n"
        f"/sms {email_name}"
    )
    client.send(Message(text=reply), thread_id=thread_id, thread_type=thread_type)


def handle_sms_command(message, message_object, thread_id, thread_type, author_id, client):
    args = message.strip().split(" ", 1)

    if len(args) < 2:
        huongdan = (
            "📥 Cách dùng: /sms [tên email]\n"
            "💡 Ví dụ:\n"
            "/sms offvnx\n\n"
            f"📧 Email mặc định: @{DEFAULT_DOMAIN}"
        )
        client.send(Message(text=huongdan), thread_id=thread_id, thread_type=thread_type)
        return

    email_name = args[1].strip()
    email = f"{email_name}@{DEFAULT_DOMAIN}"
    url = BASE_URL.format(email)

    try:
        res = requests.get(url, timeout=10)
        if res.status_code == 404:
            client.send(Message(text=f"📭 Hộp thư {email} hiện chưa có thư nào."), thread_id=thread_id, thread_type=thread_type)
            return
        elif res.status_code == 500:
            client.send(Message(text="❌ Lỗi server, vui lòng thử lại sau."), thread_id=thread_id, thread_type=thread_type)
            return
        elif res.status_code == 200:
            emails = res.json()
            if not emails:
                client.send(Message(text=f"📭 Hộp thư {email} hiện chưa có thư nào."), thread_id=thread_id, thread_type=thread_type)
                return

            reply_msg = f"📥 Hộp thư của {email}:\n"
            for idx, mail in enumerate(emails[:3], 1):
                reply_msg += (
                    f"\n━━━━━━━━━━ {idx} ━━━━━━━━━━"
                    f"\n✉️ Từ: {mail.get('from', 'Không rõ')}"
                    f"\n📌 Tiêu đề: {mail.get('subject', 'Không rõ')}"
                    f"\n📥 Gửi đến: {mail.get('to', 'Không rõ')}"
                    f"\n🕒 Thời gian: {mail.get('date', 'Không rõ')}\n"
                )
            reply_msg += "\n\n💡 Nếu chưa thấy thư, thử lại sau vài giây."

            client.send(Message(text=reply_msg), thread_id=thread_id, thread_type=thread_type)
        else:
            client.send(Message(text="❌ Lỗi không xác định, vui lòng thử lại."), thread_id=thread_id, thread_type=thread_type)
    except Exception as e:
        client.send(Message(text=f"❌ Đã xảy ra lỗi: {e}"), thread_id=thread_id, thread_type=thread_type)


def get_szl():
    return {
        'mail': handle_mail_command,
        'sms': handle_sms_command
    }