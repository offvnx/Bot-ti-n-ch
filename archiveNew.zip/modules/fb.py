from zlapi.models import Message
import requests
import os
des = {
    'version': "1.0.3",
    'credits': "Hoàng Duy Tư",
    'description': "Kiểm tra thông tin Facebook"
}
def handle_fb_command(message, message_object, thread_id, thread_type, author_id, client):
    content = message.strip().split(maxsplit=1)
    if len(content) < 2:
        client.send(
            Message(text="❌ Vui lòng nhập UID hoặc Link Facebook. Ví dụ: /fb 61574395204757 hoặc /fb facebook.com/zuck"),
            thread_id=thread_id,
            thread_type=thread_type
        )
        return

    fb_input = content[1].strip()

    if fb_input.isdigit():
        fb_id = fb_input
    else:
        if not fb_input.startswith("http"):
            fb_input = "https://" + fb_input
        try:
            convert_api = f"https://offvnx.x10.bz/api/convertID.php?url={fb_input}"
            res = requests.get(convert_api, timeout=10)
            fb_id = str(res.json().get("id", ""))
            if not fb_id.isdigit():
                client.send(Message(text="❌ Không thể lấy UID từ link Facebook này."), thread_id=thread_id, thread_type=thread_type)
                return
        except Exception:
            client.send(Message(text="🚫 Đã xảy ra lỗi khi lấy UID từ link."), thread_id=thread_id, thread_type=thread_type)
            return

    try:
        api_url = f"https://offvnx.x10.bz/fb.php?id={fb_id}&key=offvnx"
        res = requests.get(api_url)
        data = res.json().get("result", {})

        if not isinstance(data, dict) or not data:
            client.send(Message(text="❌ Không tìm thấy thông tin người dùng."), thread_id=thread_id, thread_type=thread_type)
            return

        name = data.get("name", "Không công khai")
        username = data.get("username", "Chưa thiết lập")
        profile_id = data.get("id", "Chưa thiết lập")
        link = data.get("link", f"https://facebook.com/{username}")
        picture = data.get("picture", {}).get("data", {}).get("url", "")
        is_silhouette = data.get("picture", {}).get("data", {}).get("is_silhouette", True)
        cover_url = data.get("cover", {}).get("source", "")
        created_time = data.get("created_time", "Không công khai")
        about = data.get("about", "Không công khai")
        gender = data.get("gender", "Không công khai").capitalize()
        hometown = data.get("hometown", {}).get("name", "Không công khai")
        location = data.get("location", {}).get("name", "Không công khai")
        updated_time = data.get("updated_time", "Không công khai")
        followers = data.get("followers", "Không công khai")
        following = data.get("following", "Không rõ")
        birthday = data.get("birthday", "Không hiển thị ngày sinh")
        quotes = data.get("quotes", "Không có trích dẫn")
        relationship = data.get("relationship_status", "Không công khai")
        is_verified = "Đã Xác Minh ✅" if data.get("is_verified") else "Chưa xác minh ❌"
        flag = data.get("country_flag", "Không rõ")

        significant = data.get("significant_other", {})
        significant_line = ""
        if significant.get("id"):
            significant_line = f"""│ -> 💍 Đã kết hôn với: {significant.get('name', '')}
│ -> 🔗 Link UID: https://facebook.com/{significant['id']}"""

        work_info = ""
        for job in data.get("work", []):
            position = job.get("position", {}).get("name", "")
            employer = job.get("employer", {}).get("name", "")
            work_info += f"\n│ -> Làm việc tại {position} ở {employer}"
        if not work_info:
            work_info = "Không công khai"

        edu_info = ""
        for edu in data.get("education", []):
            school = edu.get("school", {}).get("name", "")
            concentration = edu.get("concentration", [{}])[0].get("name", "")
            edu_info += f"\n│ -> Học {concentration} tại {school}"
        if not edu_info:
            edu_info = "Không công khai"

        result = f"""
╭─────────────⭓
│ 𝗡𝗮𝗺𝗲: {name}
│ 𝗨𝗜𝗗: {profile_id}
│ 𝗨𝘀𝗲𝗿𝗻𝗮𝗺𝗲: {username}
│ 𝗟𝗶𝗻𝗸: {link}
│ 𝗕𝗶𝗿𝘁𝗵𝗱𝗮𝘆: {birthday}
│ 𝗙𝗼𝗹𝗹𝗼𝘄𝗲𝗿𝘀: {followers}
│ 𝗙𝗼𝗹𝗹𝗼𝘄𝗶𝗻𝗴: {following}
│ 𝗖𝗿𝗲𝗮𝘁𝗲𝗱: {created_time}
│ 𝗩𝗲𝗿𝗶𝗳𝗶𝗲𝗱: {is_verified}
│ 𝗧𝗶̀𝗻𝗵 𝘁𝗿𝗮̣𝗻𝗴: {relationship}
{significant_line}
│ 𝗕𝗶𝗼: {about}
│ 𝗚𝗲𝗻𝗱𝗲𝗿: {gender}
│ 𝗛𝗼𝗺𝗲𝘁𝗼𝘄𝗻: {hometown}
│ 𝗟𝗼𝗰𝗮𝘁𝗶𝗼𝗻: {location}
│ 𝗪𝗼𝗿𝗸: {work_info}
│ 𝗘𝗱𝘂: {edu_info}
│ 𝗤𝘂𝗼𝘁𝗲: {quotes}
├─────────────⭔
│ 𝗟𝗮𝗻𝗴𝘂𝗮𝗴𝗲: {flag}
│ 𝗧𝗶𝗺𝗲 𝗨𝗽𝗱𝗮𝘁𝗲: {updated_time}
╰─────────────⭓
""".strip()

        if picture and not is_silhouette and picture.startswith("http"):
            try:
                img = requests.get(picture, timeout=5).content
                with open("fb_avatar.jpg", "wb") as f:
                    f.write(img)
                client.sendLocalImage(
                    "fb_avatar.jpg",
                    message=Message(text=result),
                    thread_id=thread_id,
                    thread_type=thread_type
                )
                os.remove("fb_avatar.jpg")
                return
            except:
                pass

        client.send(
            Message(text=result),
            thread_id=thread_id,
            thread_type=thread_type
        )

    except Exception as e:
        client.send(
            Message(text="🚫 Đã xảy ra lỗi khi lấy thông tin Facebook."),
            thread_id=thread_id,
            thread_type=thread_type
        )


def get_szl():
    return {
        'fb': handle_fb_command
    }