from zlapi.models import Message

des = {
    'version': "1.0.3",
    'credits': "Hoàng Duy Tư",
    'description': "Gửi danh sách source tool chia sẻ"
}

def handle_scrtool_command(message, message_object, thread_id, thread_type, author_id, client):
    if not hasattr(message_object, 'content') or not isinstance(message_object.content, str):
        return

    if not message_object.content.startswith('/scrtool'):
        return

    content = (
        "📦 TỔNG FULL SOURCE TOOL\n\n"
        "• [SOURCE TOOL] Gộp ngocv3.2.py\n"
        "🔗 https://link4m.com/lXBm1X2\n\n"
        "• [SOURCE TOOL] SHARE SOURCE CODE TOOL CỦA CÁC IDOL\n"
        "🔗 https://link4m.com/f48U00w\n\n"
        "• File SOUCRE TOOL GỘP VLONG MỚI NEW\n"
        "🔗 https://link4m.com/FtNMLPf\n\n"
        "• File SOUCRE var Messenger facebook\n"
        "🔗 https://link4m.com/rX7fQVz\n\n"
        "• File SOUCRE GEN MAIL VIP\n"
        "🔗 https://link4m.com/AhMDsm\n\n"
        "• File SOUCRE Golike Tiktok\n"
        "🔗 https://link4m.com/aELX3\n\n"
        "• File SOUCRE Spam Email\n"
        "🔗 https://link4m.com/b8taoEb\n\n"
        "• File SOUCRE Reg Nick Facebook\n"
        "🔗 https://link4m.com/WckaBu0N\n\n"
        "• File SOUCRE buff View Tiktok\n"
        "🔗 https://link4m.com/CbGuXM\n\n"
        "• File TOOL GỘP VLONG NHIỀU CHỨC NĂNG\n"
        "🔗 https://link4m.com/DNk26k\n\n"
        "• File FULL SOURCE TOOL DECODE Marshal\n"
        "🔗 https://link4m.com/bkFzPs\n\n"
        "• File FULL SOURCE TOOL DECODE hyperion\n"
        "🔗 https://link4m.com/ldv4d2En\n\n"
        "• File FULL SOURCE TOOL Kramer\n"
        "🔗 https://link4m.com/lEXcLD\n\n"
        "• File FULL SOURCE TOOL SPAM SMS VIP\n"
        "🔗 https://link4m.com/uPmWRBV\n\n"
        "• File FULL SOURCE TOOL DDOS WEBSITE\n"
        "🔗 https://link4m.com/leWreqA\n\n"
        "📊 Tổng số liên kết: 15"
    )

    client.send(
        Message(text=content),
        thread_id=thread_id,
        thread_type=thread_type
    )

def get_szl():
    return {
        'scrtool': handle_scrtool_command
    }