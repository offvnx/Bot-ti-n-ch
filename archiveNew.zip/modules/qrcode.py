from zlapi.models import Message
import requests
import urllib.parse
import random
import os

des = {
    'version': "1.0.0",
    'credits': "Hoàng Duy Tư",
    'description': "Tạo mã QR từ nội dung nhập vào"
}

def handle_qrcode_command(message, message_object, thread_id, thread_type, author_id, client):
    content_parts = message.strip().split(maxsplit=1)

    if len(content_parts) < 2 or not content_parts[1].strip():
        client.send(
            Message(text="⚠️ Vui lòng nhập nội dung để tạo mã QR.\n\n📌 Ví dụ: /qrcode Hello Zalo!"),
            thread_id=thread_id,
            thread_type=thread_type
        )
        return

    content = content_parts[1].strip()
    encoded_text = urllib.parse.quote(content, safe='')

    # Tạo màu ngẫu nhiên cho mã QR
    r = random.randint(50, 200)
    g = random.randint(50, 200)
    b = random.randint(50, 200)
    color_param = f"{r}-{g}-{b}"

    try:
        api_url = f"https://api.qrserver.com/v1/create-qr-code/?size=1600x1600&data={encoded_text}&color={color_param}"
        response = requests.get(api_url, timeout=15)

        if response.status_code != 200:
            client.send(
                Message(text=f"❌ Lỗi khi gọi API QR: HTTP {response.status_code}"),
                thread_id=thread_id,
                thread_type=thread_type
            )
            return

        image_path = 'temp_qrcode.jpg'
        with open(image_path, 'wb') as f:
            f.write(response.content)

        if os.path.exists(image_path):
            client.sendLocalImage(
                image_path,
                message=Message(text=f"✅ Mã QR đã tạo\n\n📄 Nội dung: {content}"),
                thread_id=thread_id,
                thread_type=thread_type,
                width=1600,
                height=1600
            )
            os.remove(image_path)

    except requests.exceptions.RequestException as e:
        client.send(
            Message(text=f"❌ Lỗi khi gọi API QR: {str(e)}"),
            thread_id=thread_id,
            thread_type=thread_type
        )
    except Exception as e:
        client.send(
            Message(text=f"❌ Lỗi không xác định: {str(e)}"),
            thread_id=thread_id,
            thread_type=thread_type
        )


def get_szl():
    return {
        'qrcode': handle_qrcode_command
    }