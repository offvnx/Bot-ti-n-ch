from zlapi.models import Message
import requests

des = {
    'version': "1.0.4",
    'credits': "Hoàng Duy Tư",
    'description': "Gái xinh TikTok Random, giao diện như TikTok"
}

def handle_vdgai_command(message, message_object, thread_id, thread_type, author_id, client):
    if not hasattr(message_object, 'content') or not isinstance(message_object.content, str):
        return
    if not message_object.content.startswith('/vdgai'):
        return

    client.send(Message(text="🔎 Đang tìm video gái xinh..."), thread_id, thread_type)

    try:
        res = requests.get("https://gaitiktok.onrender.com/random?apikey=randomtnt", timeout=10)
        if res.status_code != 200:
            client.send(Message(text="❌ Bot lỗi hoặc API không phản hồi."), thread_id, thread_type)
            return

        data = res.json().get("data", {})
        if not data:
            client.send(Message(text="❌ Không nhận được dữ liệu video."), thread_id, thread_type)
            return

        video_url = data['play']
        thumbnail_url = data['cover']
        title = data.get("title", "Không có tiêu đề")
        duration = int(data.get("duration", 20)) * 1000
        author = data.get("author", {})
        nickname = author.get("nickname", "Không rõ")
        uid = author.get("id", "Không rõ")
        unique_id = author.get("unique_id", "Không rõ")
        avatar = author.get("avatar", "")
        region = data.get("region", "Không rõ")

        caption = f"""
🎥 {title}
👤 Tác giả: {nickname} (@{unique_id})
🆔 UID: {uid}
🌍 Quốc gia: {region}
⏱️ Độ dài: {data.get("duration")} giây
🖼️ Avatar: {avatar}
❤️ Thích: {data.get('digg_count')}
💬 Bình luận: {data.get('comment_count')}
👁️ Xem: {data.get('play_count')}
🔄 Chia sẻ: {data.get('share_count')}
⬇️ Tải: {data.get('download_count')}
💾 Lưu: {data.get('collect_count')}
""".strip()

        # Gửi video kiểu giống tiktok
        client.sendRemoteVideo(
            video_url,
            thumbnailUrl=thumbnail_url,
            duration=duration,
            width=720,
            height=1280,
            message=Message(text=caption),
            thread_id=thread_id,
            thread_type=thread_type
        )

    except Exception as e:
        client.send(Message(text=f"❌ Lỗi khi gửi video"), thread_id, thread_type)

def get_szl():
    return {
        'vdgai': handle_vdgai_command
    }