import requests
from zlapi.models import Message

des = {
    'version': "1.0.0",
    'credits': "Hoàng Duy Tư",
    'description': "Tăng lượt thích (likes) cho UID Free Fire"
}

API_KEY = "BNGX"
API_URL = "https://bngx-like-ff.onrender.com/add_likes"

def handle_like_command(message, message_object, thread_id, thread_type, author_id, client):
    if not hasattr(message_object, 'content') or not isinstance(message_object.content, str):
        return
    if not message_object.content.startswith('/like'):
        return

    parts = message_object.content.strip().split(" ", 1)
    if len(parts) < 2:
        client.send(
            Message(text="⚠️ Vui lòng nhập đúng cú pháp:\n/like <uid>\nVí dụ: /like 12345678"),
            thread_id=thread_id,
            thread_type=thread_type
        )
        return

    uid = parts[1].strip()
    url = f"{API_URL}?uid={uid}&key={API_KEY}"

    try:
        response = requests.get(url, timeout=10)
        if response.status_code == 200:
            data = response.json()
            if data.get("status") == "success":
                message_text = f"""✅ Đã gửi yêu cầu tăng like thành công!
📍 UID: {uid}
👍 Likes đã thêm: {data.get('likes_added', 'Không rõ')}
📦 Trạng thái: {data.get('message', 'Thành công')}"""
            else:
                message_text = f"""❌ Không thể tăng like!
📍 UID: {uid}
⚠️ Lý do: {data.get('message', 'Không rõ')}"""
        else:
            message_text = f"❌ Lỗi kết nối API"
    except Exception as e:
        message_text = f"❌ Đã xảy ra lỗi"

    client.send(Message(text=message_text), thread_id=thread_id, thread_type=thread_type)

# Thêm vào get_szl
def get_szl():
    return {
        'like': handle_like_command,
    }