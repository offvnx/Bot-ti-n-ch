from zlapi.models import Message
import requests
import os

des = {
    'version': "1.0.0",
    'credits': "Hoàng Duy Tư",
    'description': "Tra cứu thông tin Roblox qua username"
}

def get_roblox_full_info(username):
    try:
        resp = requests.get(f"https://offvnx.x10.bz/api/roblox.php?username={username}", timeout=10)
        if resp.status_code != 200:
            return f"❌ Không thể truy cập API cho người dùng: {username}", None, None

        data = resp.json()
        if 'username' not in data:
            return f"❌ Không tìm thấy người dùng: {username}", None, None

        display_name = data.get('display_name', username)
        user_id = data.get('user_id', 'Không rõ')
        created = data.get('created', 'Không rõ')
        description = data.get('description', 'Không có mô tả.')
        presence = data.get('presence', 'Không rõ')
        friends_count = data.get('friends', 'Không rõ')
        followers_count = data.get('followers', 'Không rõ')
        group_names = data.get('groups', [])
        group_count = data.get('group_count', 0)
        avatar_url = data.get('avatar_url', None)
        profile_url = data.get('profile_url', f"https://www.roblox.com/users/{user_id}/profile")

        group_text = "\n".join(f"- {name}" for name in group_names[:5]) if group_names else "Không tham gia nhóm nào"

        result = f"""
👤 Thông tin ROBLOX
🧑 Tên: {username} ({display_name})
🆔 ID: {user_id}
📅 Ngày tạo: {created}
📝 Mô tả: {description or "Không có mô tả."}
🌐 Trạng thái: {presence}
👥 Số bạn bè: {friends_count}
👀 Người theo dõi: {followers_count}
🏘️ Nhóm đang tham gia ({group_count}):
{group_text}
"""
        return result.strip(), avatar_url, profile_url

    except Exception as e:
        return f"❌ Đã xảy ra lỗi: {e}", None, None

def handle_roblox_command(message, message_object, thread_id, thread_type, author_id, client):
    if not hasattr(message_object, 'content') or not isinstance(message_object.content, str):
        return

    if not message_object.content.startswith('/roblox'):
        return

    parts = message.strip().split()
    if len(parts) != 2:
        client.send(Message(text="❗ Sử dụng đúng cú pháp: /roblox mygame43"), thread_id, thread_type)
        return

    username = parts[1]
    info, avatar_url, profile_url = get_roblox_full_info(username)

    if info.startswith("❌"):
        client.send(Message(text=info), thread_id, thread_type)
        return

    roblox_text = info + f"\n🔗 Hồ sơ: {profile_url}"

    if avatar_url:
        try:
            img = requests.get(avatar_url, timeout=5).content
            with open("roblox_avatar.jpg", "wb") as f:
                f.write(img)
            client.sendLocalImage("roblox_avatar.jpg", message=Message(text=roblox_text), thread_id=thread_id, thread_type=thread_type)
            os.remove("roblox_avatar.jpg")
        except:
            client.send(Message(text=roblox_text), thread_id=thread_id, thread_type=thread_type)
    else:
        client.send(Message(text=roblox_text), thread_id=thread_id, thread_type=thread_type)

def get_szl():
    return {
        'roblox': handle_roblox_command
    }