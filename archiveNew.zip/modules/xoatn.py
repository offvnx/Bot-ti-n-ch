from zlapi.models import *
from zlapi import Message, ThreadType
from config import PREFIX
from datetime import datetime, timedelta
import time
import threading

# Khai báo ADMIN cố định ở đây
ADMIN = [2198731144905101625]

# Metadata mô tả
des = {
    'version': "1.0.4",
    'credits': "Hoàng Duy Tư",
    'description': "Tự động xoá tin nhắn mỗi 1 phút sau khi gọi /xoatn"
}

# Danh sách nhóm đã kích hoạt auto
auto_delete_threads = set()

# Hàm xóa tin nhắn
def delete_messages(client, thread_id, thread_type, author_id, num_to_delete=100):
    try:
        group_data = client.getRecentGroup(thread_id)
        if not group_data or not hasattr(group_data, 'groupMsgs'):
            return 0, 0  # Không có dữ liệu

        messages_to_delete = group_data.groupMsgs
        if not messages_to_delete:
            return 0, 0

        if len(messages_to_delete) < num_to_delete:
            num_to_delete = len(messages_to_delete)

        deleted_count = 0
        failed_count = 0

        for i in range(num_to_delete):
            msg = messages_to_delete[-(i + 1)]
            user_id = str(msg['uidFrom']) if msg['uidFrom'] != '0' else author_id
            try:
                deleted_msg = client.deleteGroupMsg(msg['msgId'], user_id, msg['cliMsgId'], thread_id)
                if deleted_msg.status == 0:
                    deleted_count += 1
                else:
                    failed_count += 1
            except Exception:
                failed_count += 1
                continue

        return deleted_count, failed_count

    except Exception:
        return 0, 0

# Hàm xử lý lệnh /xoatn
def handle_go_command(message, message_object, thread_id, thread_type, author_id, client):
    if int(author_id) not in ADMIN:
        noquyen = "⛔ Bạn không có quyền để thực hiện điều này!"
        client.replyMessage(Message(text=noquyen), message_object, thread_id, thread_type)
        return

    # Gọi xóa ngay lần đầu
    deleted_count, failed_count = delete_messages(client, thread_id, thread_type, author_id)

    if deleted_count == 0 and failed_count == 0:
        reply = "❌ Không có tin nhắn nào để xóa hoặc gặp lỗi."
    elif failed_count > 0:
        reply = f"✅ Đã xóa {deleted_count} tin nhắn.\n⚠️ Không thể xóa {failed_count} tin nhắn."
    else:
        reply = f"✅ Đã xóa {deleted_count} tin nhắn thành công!"

    client.replyMessage(Message(text=reply), message_object, thread_id, thread_type)

    # Nếu nhóm chưa chạy auto thì chạy mới
    if thread_id not in auto_delete_threads:
        auto_delete_threads.add(thread_id)
        start_auto_delete(client, thread_id, author_id)

# Tự động xóa mỗi 1 phút sau khi /xoatn
def start_auto_delete(client, thread_id, author_id):
    def run():
        while True:
            deleted_count, failed_count = delete_messages(client, thread_id, ThreadType.GROUP, author_id)
            print(f"[AUTO DELETE] Nhóm {thread_id} → Xóa: {deleted_count} | Lỗi: {failed_count}")
            time.sleep(1800)  # 1 phút

    threading.Thread(target=run, daemon=True).start()

# Mapping command
def get_szl():
    return {
        'xoatn': handle_go_command
    }