from zlapi.models import Message
import requests
import urllib.parse
from datetime import datetime

des = {
    'version': "1.0.2",
    'credits': "Hoàng Duy Tư",
    'description': "Lấy token Facebook EAAD6V7 từ cookie"
}

def handle_token_command(message, message_object, thread_id, thread_type, author_id, client):
    args = message.strip().split(" ", 1)

    if len(args) < 2:
        huongdan = (
            "📌 Cách dùng: /token [cookie Facebook]\n"
            "💡 Ví dụ:\n"
            "/token datr=abc...;c_user=12345;xs=xyz...\n\n"
            "⚠️ Token mặc định là loại EAAD6V7 - Facebook Lite"
        )
        client.send(Message(text=huongdan), thread_id=thread_id, thread_type=thread_type)
        return

    cookie = args[1].strip()
    encoded_cookie = urllib.parse.quote(cookie)
    api_url = f"https://api.zeidteam.xyz/facebook/gettoken?cookie={encoded_cookie}&type=EAAD6V7"

    try:
        res = requests.get(api_url, timeout=10)
        if res.status_code == 200:
            data = res.json()
            if data.get("success") and "tokenInfo" in data:
                token_info = data["tokenInfo"]
                token = token_info.get("token", "Không có token.")
                token_type = token_info.get("type", "Không rõ loại")
                gen_time = data.get("generatedAt", "")
                version = data.get("apiVersion", "?")

                if gen_time:
                    try:
                        gen_time_fmt = datetime.strptime(gen_time, "%Y-%m-%dT%H:%M:%S.%fZ").strftime("%H:%M:%S %d/%m/%Y")
                    except ValueError:
                        gen_time_fmt = gen_time
                else:
                    gen_time_fmt = "Không rõ"

                response = (
                    "✅ LẤY TOKEN THÀNH CÔNG\n\n"
                    f"🔖 Loại token: {token_type}\n"
                    f"🔐 Token:\n{token}\n\n"
                    f"🕒 Thời gian tạo: {gen_time_fmt}\n"
                    f"🧩 Phiên bản API: {version}\n\n"
                    "⚠️ Không chia sẻ token cho người khác để tránh mất tài khoản."
                )
            else:
                response = f"❌ Lỗi: {data.get('message', 'Không rõ nguyên nhân.')}"
        else:
            response = f"❌ Máy chủ không phản hồi. Mã lỗi: {res.status_code}"
    except Exception as e:
        response = f"❌ Đã xảy ra lỗi: {e}"

    client.send(Message(text=response), thread_id=thread_id, thread_type=thread_type)

def get_szl():
    return {'token': handle_token_command}