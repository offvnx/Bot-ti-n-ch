from zlapi.models import Message
import requests
import os

des = {
    'version': "1.0.3",
    'credits': "Hoàng Duy Tư",
    'description': "Tải video TikTok API OFFVNX (không tự động xóa)"
}

def handle_tiktok_command(message, message_object, thread_id, thread_type, author_id, client):
    content = message.strip().split()
    if len(content) < 2:
        client.sendMessage(Message(text="⚠️ Vui lòng nhập một đường link TikTok hợp lệ."), thread_id, thread_type)
        return

    url = content[1].strip()
    if "tiktok.com" not in url:
        client.sendMessage(Message(text="⚠️ Link TikTok không hợp lệ."), thread_id, thread_type)
        return

    api_url = f'https://offvnx.x10.bz/api/video.php?url={requests.utils.quote(url)}'
    try:
        res = requests.get(api_url)
        data = res.json()
    except Exception as e:
        client.sendMessage(Message(text=f"❌ Lỗi khi gọi API: {e}"), thread_id, thread_type)
        return

    if data.get('msg') != 'success' or 'data' not in data:
        client.sendMessage(Message(text="❌ Không thể tải video từ liên kết đã cung cấp."), thread_id, thread_type)
        return

    d = data['data']
    video_url = d.get('play')
    thumbnail_url = d.get('cover')
    music_info = d.get("music_info", {})
    music_title = music_info.get("title", "Không rõ")
    music_author = music_info.get("author", "Không rõ")
    music_duration = music_info.get("duration", "Không rõ")

    is_ad = "Có" if d.get('is_ad') else "Không"
    duration = d.get("duration") or music_duration
    size = d.get("size") or "Không rõ"
    region = d.get("region", "Không rõ")

    caption = f"""
🎥 {d.get('title')}
👤 Tác giả: {d['author']['nickname']} (@{d['author']['unique_id']})
🌍 Khu vực: {region}
🎮 Độ dài video: {duration} giây
🎵 Nhạc: {music_title} - {music_author}
🗓️ Ngày đăng: {d.get('create_time')}
📢 Quảng cáo: {is_ad}
🗂️ Dung lượng: {size} MB
---------------------------------------
▶️ Lượt xem: {d.get('play_count')}
❤️ Lượt thích: {d.get('digg_count')}
💬 Bình luận: {d.get('comment_count')}
🔄 Chia sẻ: {d.get('share_count')}
⬇️ Tải xuống: {d.get('download_count')}
📥 Lưu: {d.get('collect_count')}
""".strip()

    try:
        video_size_mb = float(size)
    except:
        video_size_mb = 0

    # Nếu là ảnh slide
    if 'images' in d and d['images']:
        images = d['images']
        for i, img_url in enumerate(images):
            try:
                img_data = requests.get(img_url, timeout=10).content
                img_path = f"tiktok_img_{i}.jpg"
                with open(img_path, 'wb') as f:
                    f.write(img_data)
                msg = Message(text=caption) if i == 0 else None
                client.sendLocalImage(img_path, message=msg, thread_id=thread_id, thread_type=thread_type)
                os.remove(img_path)
            except Exception as e:
                client.sendMessage(Message(text=f"⚠️ Không thể gửi ảnh {i+1}: {e}"), thread_id=thread_id, thread_type=thread_type)
        return

    # Nếu video quá lớn
    if video_size_mb > 20:
        caption += f"\n\n⚠️ Video quá lớn không thể gửi trực tiếp. Tải tại: https://api.zm.io.vn/download/?url={video_url}&extension=mp4&name=downvideott_zalo&quality=watermark"
        client.sendMessage(Message(text=caption), thread_id, thread_type)
        return

    # Gửi video bình thường
    duration_ms = int(duration) * 1000 if duration else 20000
    try:
        client.sendRemoteVideo(
            video_url,
            thumbnailUrl=thumbnail_url,
            duration=duration_ms,
            message=Message(text=caption),
            thread_id=thread_id,
            thread_type=thread_type,
            width=720,
            height=1280
        )
    except Exception as e:
        client.sendMessage(Message(text=f"⚠️ Không thể gửi video: {e}"), thread_id=thread_type, thread_type=thread_type)

def get_szl():
    return {
        'tiktok': handle_tiktok_command
    }