from zlapi.models import Message
import requests
import mimetypes
import os

des = {
    'version': "1.0.5",
    'credits': "Hoàng Duy Tư",
    'description': "Tải video đa nền tảng + gửi video/ảnh"
}

def is_image_url(url):
    mime_type, _ = mimetypes.guess_type(url)
    return mime_type and mime_type.startswith('image')

def handle_down_command(message, message_object, thread_id, thread_type, author_id, client):
    if not hasattr(message_object, 'content') or not isinstance(message_object.content, str):
        return

    if not message_object.content.startswith('/down'):
        return

    args = message.strip().split(' ', 1)
    if len(args) < 2:
        client.send(
            Message(text=(
                "⚠️ Vui lòng nhập link để tải sau lệnh /down.\n\n"
                "💭 Ví dụ: /down https://www.youtube.com/watch?v=abcd\n\n"
                "🌐 Hỗ trợ: TikTok, Douyin, Threads, Instagram, Facebook, Pinterest, Reddit, Twitter, Snapchat, Bilibili, LinkedIn, Telegram, Soundcloud, Spotify, ZingMP3.\n\n"
                "❗️ Lưu ý: Video quá dài có thể không gửi được."
            )),
            thread_id=thread_id,
            thread_type=thread_type
        )
        return

    url = args[1].strip()

    try:
        api_url = f"https://api.zeidteam.xyz/media-downloader/atd2?url={url}"
        res = requests.get(api_url, timeout=20)

        if res.status_code != 200:
            client.send(Message(text="❌ API không phản hồi!"), thread_id=thread_id, thread_type=thread_type)
            return

        data = res.json()
        if data.get("error"):
            client.send(Message(text="❌ API trả về lỗi."), thread_id=thread_id, thread_type=thread_type)
            return

        title = data.get("title", "🎬 Video")
        thumbnail = data.get("thumbnail")
        medias = data.get("medias", [])

        caption = f"🎬 {title}\n\n📥 Link tải video:\n"
        best_video = None

        if not medias:
            caption += "⚠️ Không có video khả dụng."
        else:
            for media in medias:
                ext = media.get("extension", "").upper()
                quality = media.get("quality", "")
                media_url = media.get("url", "")
                caption += f"\n🔗 {ext} ({quality}): {media_url}"
                if best_video is None and ext.lower() == "mp4":
                    best_video = media

        if best_video:
            video_url = best_video["url"]
            duration_ms = int(data.get("duration", 15_000))

            client.sendRemoteVideo(
                video_url,
                thumbnailUrl=thumbnail if is_image_url(thumbnail) else None,
                duration=duration_ms,
                message=Message(text=caption),
                thread_id=thread_id,
                thread_type=thread_type,
                width=720,
                height=1280
            )
            return

        if thumbnail and is_image_url(thumbnail):
            try:
                img = requests.get(thumbnail, timeout=5).content
                with open("thumb.jpg", "wb") as f:
                    f.write(img)
                client.sendLocalImage(
                    "thumb.jpg",
                    message=Message(text=caption),
                    thread_id=thread_id,
                    thread_type=thread_type
                )
                os.remove("thumb.jpg")
                return
            except Exception as e:
                print("❌ Lỗi gửi thumbnail:", e)

        client.send(Message(text=caption), thread_id=thread_id, thread_type=thread_type)

    except Exception as e:
        print("❌ Lỗi:", e)
        client.send(Message(text="⚠️ Đã xảy ra lỗi khi xử lý."), thread_id=thread_id, thread_type=thread_type)

def get_szl():
    return {
        'down': handle_down_command
    }