from zlapi.models import Message
import requests
import os

des = {
    'version': "1.0.0",
    'credits': "Hoàng Duy Tư",
    'description': "Tra cứu thông tin GitHub user"
}

def handle_github_command(message, message_object, thread_id, thread_type, author_id, client):
    if not hasattr(message_object, 'content') or not isinstance(message_object.content, str):
        return

    if not message_object.content.startswith('/github'):
        return

    parts = message.strip().split(maxsplit=1)
    if len(parts) < 2 or not parts[1].strip():
        client.send(
            Message(text="❌ Vui lòng cung cấp tên người dùng GitHub sau lệnh /github."),
            thread_id=thread_id,
            thread_type=thread_type
        )
        return

    username = parts[1].strip()
    url = f"https://api.github.com/users/{username}"
    headers = {'User-Agent': 'request'}

    try:
        resp = requests.get(url, headers=headers, timeout=10)
        if resp.status_code == 200:
            data = resp.json()
            info = (
                f"🔍 Thông tin GitHub của {username}:\n\n"
                f"👤 Tên đăng nhập: {data.get('login', 'Không có')}\n"
                f"🆔 ID: {data.get('id', 'Không rõ')}\n"
                f"📝 Tên đầy đủ: {data.get('name', 'Không có tên')}\n"
                f"🔗 URL hồ sơ: {data.get('html_url', 'Không có')}\n"
                f"🏢 Công ty: {data.get('company', 'Không có thông tin')}\n"
                f"📍 Vị trí: {data.get('location', 'Không có thông tin')}\n"
                f"📧 Email: {data.get('email', 'Không công khai')}\n"
                f"💼 Hireable: {'Có thể thuê' if data.get('hireable') else 'Không thể thuê hoặc không công khai'}\n"
                f"💬 Bio: {data.get('bio', 'Không có thông tin')}\n"
                f"🌐 Blog: {data.get('blog', 'Không có URL blog')}\n"
                f"🔦 Twitter: {data.get('twitter_username', 'Không có Twitter')}\n"
                f"🕒 Ngày tạo tài khoản: {data.get('created_at', 'Không rõ')}\n"
                f"🕒 Ngày cập nhật: {data.get('updated_at', 'Không rõ')}\n"
                f"📂 Repositories công khai: {data.get('public_repos', 0)}\n"
                f"📂 Gists công khai: {data.get('public_gists', 0)}\n"
                f"⭐ Follower: {data.get('followers', 0)} | Đang follow: {data.get('following', 0)}\n"
                f"🏷️ Loại tài khoản: {data.get('type', 'Không rõ')}\n"
                f"🔗 Site admin: {'✅' if data.get('site_admin') else '❌'}\n"
            )

            avatar_url = data.get('avatar_url')
            if avatar_url and avatar_url.startswith("http"):
                try:
                    img = requests.get(avatar_url, timeout=5).content
                    path = "github_avatar.jpg"
                    with open(path, "wb") as f:
                        f.write(img)
                    client.sendLocalImage(
                        path,
                        message=Message(text=info),
                        thread_id=thread_id,
                        thread_type=thread_type
                    )
                    os.remove(path)
                except Exception:
                    client.send(Message(text=info), thread_id=thread_id, thread_type=thread_type)
            else:
                client.send(Message(text=info), thread_id=thread_id, thread_type=thread_type)

        elif resp.status_code == 404:
            client.send(Message(text="❌ Không tìm thấy người dùng GitHub này."), thread_id=thread_id, thread_type=thread_type)
        elif resp.status_code == 403:
            client.send(Message(text="❌ Đã vượt giới hạn truy vấn API GitHub. Vui lòng thử lại sau."), thread_id=thread_id, thread_type=thread_type)
        else:
            client.send(Message(text=f"❌ Lỗi không xác định từ GitHub (mã {resp.status_code})."), thread_id=thread_id, thread_type=thread_type)

    except requests.exceptions.Timeout:
        client.send(Message(text="❌ Quá thời gian chờ phản hồi từ GitHub."), thread_id=thread_id, thread_type=thread_type)
    except Exception as e:
        client.send(Message(text=f"❌ Đã xảy ra lỗi khi lấy thông tin GitHub: {e}"), thread_id=thread_id, thread_type=thread_type)


def get_szl():
    return {
        'github': handle_github_command,
        # thêm các lệnh khác ở đây nếu cần
    }