from zlapi.models import Message
import hashlib
import json
import subprocess
import random
import os
import re
import requests
import threading
from datetime import datetime, timedelta, timezone

last_used = {}
VIDEO_SPAM = "https://offvnx.x10.bz/chao.mp4"
USER_FILE = 'used_keys.txt'
VIP_FILE = 'vip_data.json'
ADMIN_IDS = ['2198731144905101625']  # Thay bằng ID thật của admin

des = {
    'version': "1.0.3",
    'credits': "Hoàng Duy Tư",
    'description': "Xác thực KEY ZALO - BOT VIP"
}

def get_carrier_info(phone):
    prefixes = {
        "086": "Viettel", "096": "Viettel", "097": "Viettel", "098": "Viettel", "032": "Viettel", "033": "Viettel", "034": "Viettel", "035": "Viettel", "036": "Viettel", "037": "Viettel", "038": "Viettel", "039": "Viettel",
        "090": "Mobifone", "093": "Mobifone", "089": "Mobifone", "070": "Mobifone", "079": "Mobifone", "077": "Mobifone", "076": "Mobifone", "078": "Mobifone",
        "091": "Vinaphone", "094": "Vinaphone", "088": "Vinaphone", "083": "Vinaphone", "084": "Vinaphone", "085": "Vinaphone", "081": "Vinaphone", "082": "Vinaphone",
        "092": "Vietnamobile", "056": "Vietnamobile", "058": "Vietnamobile",
        "099": "Gmobile", "059": "Gmobile"
    }
    prefix = phone[:3]
    carrier = prefixes.get(prefix, "Không xác định")
    return prefix, carrier

def get_vn_time():
    vn_timezone = timezone(timedelta(hours=7))
    return datetime.now(vn_timezone)

def generate_short_key(user_id, ngay):
    raw = f"{user_id}-{ngay}"
    hashed = hashlib.sha256(raw.encode()).hexdigest()
    short_key = hashed[:10].upper()
    return f"BOT/{short_key}"

def ensure_user_file():
    if not os.path.exists(USER_FILE):
        with open(USER_FILE, 'w', encoding='utf-8') as f:
            pass

def is_key_used_today(user_id, key):
    today_str = get_vn_time().strftime('%d/%m/%Y')
    with open(USER_FILE, 'r', encoding='utf-8') as f:
        for line in f:
            try:
                uid, used_key, date_str = line.strip().split('|')
                if str(user_id) == uid and used_key == key and date_str == today_str:
                    return True
            except:
                continue
    return False

def save_user_key(user_id, key):
    today_str = get_vn_time().strftime('%d/%m/%Y')
    with open(USER_FILE, 'a', encoding='utf-8') as f:
        f.write(f"{user_id}|{key}|{today_str}\n")

def handle_getkey_command(message, message_object, thread_id, thread_type, author_id, client):
    ngay = int(get_vn_time().strftime('%d'))
    key = generate_short_key(author_id, ngay)
    tgsuccess = get_vn_time().strftime("%d/%m/%Y %H:%M:%S")
    url = f"https://link4m.co/api-shorten/v2?api=6506fd36fba45f6d07613987&url=https://offvn.io.vn?key={key}"

    try:
        data = requests.get(url, timeout=10).json()
        linkvuot = data.get('shortenedUrl', 'LỖI API')
    except:
        linkvuot = 'LỖI API'

    msg = f"""Xin chào bạn!
🔐 KEY NGÀY: {tgsuccess}
🔗 Link vượt: {linkvuot}

⚠️ HƯỚNG DẪN:
1️⃣ Truy cập link trên, lấy key vượt link.
2️⃣ Dùng lệnh /key BOT/ABC1234567 để xác thực key
💡 Ví dụ: /k BOT/B7BC8D325E
📩 Sau khi xác thực, bạn có thể dùng được lệnh
"""
    client.sendMessage(Message(text=msg), thread_id, thread_type)

def handle_key_command(message, message_object, thread_id, thread_type, author_id, client):
    content = message.strip().split()
    if len(content) < 2:
        client.sendMessage(Message(text="⚠️ Vui lòng nhập key hợp lệ, ví dụ: key BOT/ABC1234567"), thread_id, thread_type)
        return

    input_key = content[1].strip()
    ngay = int(get_vn_time().strftime('%d'))
    key = generate_short_key(author_id, ngay)

    ensure_user_file()
    if input_key == key:
        if is_key_used_today(author_id, key):
            client.sendMessage(Message(text="✅ Bạn đã xác nhận key hôm nay rồi!"), thread_id, thread_type)
            return

        save_user_key(author_id, key)
        client.sendMessage(Message(text=f"✅ Nhập key thành công lúc {get_vn_time().strftime('%H:%M:%S %d/%m/%Y')}!\nBạn có thể dùng các lệnh VIP."), thread_id, thread_type)

        for admin in ADMIN_IDS:
            try:
                client.sendMessage(
                    Message(text=f"🔑 Người dùng xác nhận key:\n👤 ID: {author_id}\n🔐 Key: {key}"),
                    admin,
                    thread_type
                )
            except:
                continue
    else:
        client.sendMessage(Message(text="❌ Key không hợp lệ. Hãy dùng lệnh /getkey để nhận lại."), thread_id, thread_type)

def handle_spam_command(message, message_object, thread_id, thread_type, author_id, client):
    args = message.strip().split()
    now = get_vn_time()
    ensure_user_file()

    # Giới hạn thời gian giữa 2 lần spam
    if author_id in last_used:
        elapsed = (now - last_used[author_id]).total_seconds()
        if elapsed < 300:
            remaining = int(300 - elapsed)
            client.sendMessage(Message(
                text=f"❌ Vui lòng đợi {remaining} giây để tiếp tục sử dụng lệnh FREE.\n⚠️ Mua VIP để dùng không giới hạn."), thread_id, thread_type)
            return

    if len(args) < 3:
        client.sendMessage(Message(
            text="⚠️ Hướng dẫn dùng: /spam [sdt] [số lần]\nVí dụ: /spam 0969549113 3"), thread_id, thread_type)
        return

    phone = args[1]
    try:
        solan = int(args[2])
    except:
        client.sendMessage(Message(text="⚠️ Số lần phải là số!"), thread_id, thread_type)
        return

    if solan > 5:
        client.sendMessage(Message(
            text="⚠️ Lệnh FREE chỉ hỗ trợ tối đa 5 lần. Dùng VIP để spam nhiều hơn!"), thread_id, thread_type)
        return

    # Kiểm tra định dạng SDT
    if not re.fullmatch(r"^(0?)(3[2-9]|5[6|8|9]|7[06-9]|8[1-6,8,9]|9[0-4,6-9])[0-9]{7}$", phone):
        client.sendMessage(Message(text="❌ Số điện thoại không hợp lệ!"), thread_id, thread_type)
        return

    if phone in ["0763633372"]:
        client.sendMessage(Message(text="❌ Số điện thoại này bị cấm spam!"), thread_id, thread_type)
        return

    # Kiểm tra key ngày
    key = generate_short_key(author_id, int(now.strftime('%d')))
    allowed = False
    with open(USER_FILE, 'r', encoding='utf-8') as f:
        for line in f:
            if str(author_id) in line and key in line:
                allowed = True
                break
    if not allowed:
        client.sendMessage(Message(text="⚠️ Bạn chưa xác thực key ngày hôm nay!\n💬 Hãy dùng lệnh /getkey để nhận key."), thread_id, thread_type)
        return

    # Lấy thông tin nhà mạng
    prefix, carrier = get_carrier_info(phone)
    dache = phone[:2] + "******" + phone[8:]
    tg_hethan_free = datetime.now().replace(hour=23, minute=59, second=59).strftime("%d/%m/%Y %H:%M:%S")

    caption = f"""📲 TẤN CÔNG ĐÃ GỬI ĐI
👤 ID: {author_id}
📵 Phone: {dache}
🔄 Lặp: {solan}
🔢 Mã vùng: {prefix}
📡 Nhà mạng: {carrier}
💰 Plan: FREE
⏳ Hết hạn key: {tg_hethan_free}"""

    client.sendRemoteVideo(
        VIDEO_SPAM,
        thumbnailUrl=None,
        duration=10000,
        message=Message(text=caption),
        thread_id=thread_id,
        thread_type=thread_type
    )

    # Gọi script sms.py
    def run_sms_script():
        try:
            process = subprocess.Popen(['python3', 'sms.py', phone, str(solan)],
                                       stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
            stdout, stderr = process.communicate()

            try:
                result = json.loads(stdout)
                success = result.get("success", 0)
                fail = result.get("fail", 0)
            except:
                success = solan
                fail = 0

            report = f"""📊 BÁO CÁO GỬI TIN NHẮN
📱 SĐT: {dache}
✅ Thành công: {success}
❌ Thất bại: {fail}"""
            client.sendMessage(Message(text=report), thread_id, thread_type)
            last_used[author_id] = now

        except Exception as e:
            client.sendMessage(Message(text=f"Lỗi khi gửi SMS: {e}"), thread_id, thread_type)

    threading.Thread(target=run_sms_script).start()

def handle_spamvip_command(message, message_object, thread_id, thread_type, author_id, client):
    args = message.strip().split()
    now = get_vn_time()

    if len(args) < 3:
        client.sendMessage(Message(
            text="⚠️ Hướng dẫn dùng: /spamvip [sdt] [số lần]\nVí dụ: /spamvip 0969549113 20"), thread_id, thread_type)
        return

    phone = args[1]
    try:
        solan = int(args[2])
    except:
        client.sendMessage(Message(text="⚠️ Số lần phải là số!"), thread_id, thread_type)
        return

    if solan > 50 or solan < 1:
        client.sendMessage(Message(
            text="⚠️ Bạn chỉ được spam từ 1 đến 50 lần!"), thread_id, thread_type)
        return

    # Kiểm tra định dạng SDT
    if not re.fullmatch(r"^(0?)(3[2-9]|5[6|8|9]|7[06-9]|8[1-6,8,9]|9[0-4,6-9])[0-9]{7}$", phone):
        client.sendMessage(Message(text="❌ Số điện thoại không hợp lệ!"), thread_id, thread_type)
        return

    if phone in ["0763633372"]:
        client.sendMessage(Message(text="❌ Số điện thoại này bị cấm spam!"), thread_id, thread_type)
        return

    # Giới hạn spam VIP mỗi 100 giây
    if author_id in last_used:
        elapsed = (now - last_used[author_id]).total_seconds()
        if elapsed < 100:
            remaining = int(100 - elapsed)
            client.sendMessage(Message(
                text=f"❌ Vui lòng đợi {remaining} giây để tiếp tục dùng lệnh VIP."), thread_id, thread_type)
            return

    # Kiểm tra VIP từ vip_data.json
    if not os.path.exists(VIP_FILE):
        client.sendMessage(Message(text="🚫 Chưa có dữ liệu VIP!"), thread_id, thread_type)
        return

    try:
        with open(VIP_FILE, 'r', encoding='utf-8') as f:
            vip_data = json.load(f)
    except:
        client.sendMessage(Message(text="🚫 Không thể đọc dữ liệu VIP!"), thread_id, thread_type)
        return

    uid_str = str(author_id)
    if uid_str not in vip_data:
        client.sendMessage(Message(text="🚫 Bạn chưa đăng ký VIP!\n💬 Hãy liên hệ admin hoặc dùng lệnh /muavip để mua VIP."), thread_id, thread_type)
        return

    tghethan = vip_data[uid_str]['tghethan']
    try:
        expire_time = datetime.strptime(str(tghethan), "%Y%m%d%H%M%S")
        expire_str = expire_time.strftime("%d/%m/%Y %H:%M:%S")
    except:
        expire_str = "Không xác định"

    # Lấy thông tin nhà mạng
    prefix, carrier = get_carrier_info(phone)
    dache = phone[:2] + "******" + phone[8:]

    caption = f"""📲 TẤN CÔNG VIP ĐÃ GỬI ĐI
👤 ID: {author_id}
📵 Phone: {dache}
🔄 Lặp: {solan}
🔢 Mã vùng: {prefix}
📡 Nhà mạng: {carrier}
💰 Plan: VIP
⏳ Hạn VIP: {expire_str}"""

    client.sendRemoteVideo(
        VIDEO_SPAM,
        thumbnailUrl=None,
        duration=10000,
        message=Message(text=caption),
        thread_id=thread_id,
        thread_type=thread_type
    )

    # Gọi vip.py thay vì sms.py
    def run_vip_script():
        try:
            process = subprocess.Popen(['python3', 'vip.py', phone, str(solan)],
                                       stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
            stdout, stderr = process.communicate()

            try:
                result = json.loads(stdout)
                success = result.get("success", 0)
                fail = result.get("fail", 0)
            except:
                success = solan
                fail = 0

            report = f"""📊 BÁO CÁO GỬI TIN NHẮN
📱 SĐT: {dache}
✅ Thành công: {success}
❌ Thất bại: {fail}"""
            client.sendMessage(Message(text=report), thread_id, thread_type)
            last_used[author_id] = now

        except Exception as e:
            client.sendMessage(Message(text=f"Lỗi khi gửi VIP: {e}"), thread_id, thread_type)

    threading.Thread(target=run_vip_script).start()
    
# THÊM LỆNH /themvip
def handle_add_vip_command(message, message_object, thread_id, thread_type, author_id, client):
    if str(author_id) not in ADMIN_IDS:
        client.sendMessage(Message(text="🚫 Bạn không có quyền sử dụng lệnh này!"), thread_id, thread_type)
        return

    args = message.strip().split()
    if len(args) < 3:
        client.sendMessage(Message(
            text="⚠️ Hướng dẫn dùng: /themvip [uid] [số ngày]\nVí dụ: /themvip 123456789 30"), thread_id, thread_type)
        return

    uid = args[1]
    try:
        ngay = int(args[2])
        if ngay <= 0 or ngay > 365:
            raise Exception("Số ngày không hợp lệ")
    except:
        client.sendMessage(Message(text="❌ Số ngày không hợp lệ!"), thread_id, thread_type)
        return

    expire_time = datetime.now() + timedelta(days=ngay)
    expire_str = expire_time.strftime("%Y%m%d%H%M%S")
    expire_view = expire_time.strftime("%d/%m/%Y %H:%M:%S")

    if not os.path.exists(VIP_FILE):
        with open(VIP_FILE, 'w', encoding='utf-8') as f:
            json.dump({}, f, ensure_ascii=False, indent=2)

    try:
        with open(VIP_FILE, 'r', encoding='utf-8') as f:
            vip_data = json.load(f)
    except:
        vip_data = {}

    vip_data[uid] = {
        "tghethan": expire_str
    }

    try:
        with open(VIP_FILE, 'w', encoding='utf-8') as f:
            json.dump(vip_data, f, ensure_ascii=False, indent=2)
        client.sendMessage(Message(text=f"✅ Đã thêm VIP cho ID {uid} đến {expire_view}."), thread_id, thread_type)
    except Exception as e:
        client.sendMessage(Message(text=f"❌ Lỗi ghi file VIP: {e}"), thread_id, thread_type)

# ĐĂNG KÝ CÁC LỆNH VỚI BOT
def get_szl():
    return {
        'getkey': handle_getkey_command,
        'key': handle_key_command,
        'spam': handle_spam_command,
        'spamvip': handle_spamvip_command,
        'themvip': handle_add_vip_command
    }