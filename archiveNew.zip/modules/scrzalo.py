from zlapi.models import Message

des = {
    'version': "1.0.1",
    'credits': "Hoàng Duy Tư",
    'description': "Gửi danh sách link source bot Zalo"
}

def handle_scr_command(message, message_object, thread_id, thread_type, author_id, client):
    if not hasattr(message_object, 'content') or not isinstance(message_object.content, str):
        return

    if not message_object.content.startswith('/scrzalo'):
        return

    content = (
        "📦 TỔNG FULL SOURCE BOT ZALO\n\n"
        "• File Lấy Cookie Imel Zalo\n"
        "🔗 https://link4m.com/yb7Cr (📈 352 lượt nhấp)\n\n"
        "• File Anti Thu Hồi Bot Zalo\n"
        "🔗 https://link4m.com/UlgI4w (📈 298 lượt nhấp)\n\n"
        "• File SPAM CALL SMS Bot Zalo\n"
        "🔗 https://link4m.com/eWB7SZ61 (📈 421 lượt nhấp)\n\n"
        "• File Check Info Bot Zalo\n"
        "🔗 https://link4m.com/sPc7IDE7 (📈 287 lượt nhấp)\n\n"
        "• File Laek Gộp VIP Bot Zalo\n"
        "🔗 https://link4m.com/D5Xlbxb (📈 334 lượt nhấp)\n\n"
        "• File Quản Lý Bot Zalo\n"
        "🔗 https://link4m.com/gJmUl7s (📈 259 lượt nhấp)\n\n"
        "• File Lấy Nhạc Từ Soundcloud Bot Zalo\n"
        "🔗 https://link4m.com/iaoAn2y (📈 211 lượt nhấp)\n\n"
        "• File Cho Dân War Bot Zalo\n"
        "🔗 https://link4m.com/sJJ47IDc (📈 184 lượt nhấp)\n\n"
        "• File Chào TV Mới Bot Zalo\n"
        "🔗 https://link4m.com/LCUFH (📈 146 lượt nhấp)\n\n"
        "• File Gộp Bot Zalo VIP\n"
        "🔗 https://link4m.com/klbSWrbE (📈 304 lượt nhấp)\n\n"
        "• File Check Info Zalo VIP\n"
        "🔗 https://link4m.com/c3Yp8F (📈 372 lượt nhấp)\n\n"
        "📊 Tổng số liên kết: 11"
    )

    client.send(
        Message(text=content),
        thread_id=thread_id,
        thread_type=thread_type
    )

def get_szl():
    return {
        'scrzalo': handle_scr_command
    }