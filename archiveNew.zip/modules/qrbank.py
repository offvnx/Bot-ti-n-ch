from zlapi.models import Message
import requests
import os
import urllib.parse
import tempfile

des = {
    'version': "1.0.3",
    'credits': "Hoàng Duy Tư",
    'description': "Tạo mã QR chuyển khoản ngân hàng"
}

BANK_LIST = [
    "mbbank", "dongabank", "vietinbank", "vietcombank", "techcombank",
    "bidv", "acb", "sacombank", "vpbank", "agribank",
    "hdbank", "tpbank", "shb", "eximbank", "ocb",
    "seabank", "bacabank", "pvcombank", "scb", "vib",
    "namabank", "abbank", "lpbank", "vietabank", "msb",
    "nvbank", "pgbank", "publicbank", "cimbbank", "uob"
]

def handle_qrbank_command(message, message_object, thread_id, thread_type, author_id, client):
    content = message.strip().split(maxsplit=5)
    if len(content) < 3:
        client.send(
            Message(text=(
                "❌ Cú pháp sai!\n"
                "📌 Dùng: /qrbank [STK] [BANK] [Số tiền] [Tên người nhận] [Nội dung CK]\n"
                "💡 Ví dụ:\n"
                "/qrbank 123456789 mbbank 50000 NguyenVanA Thanh toan don hang"
            )),
            thread_id=thread_id,
            thread_type=thread_type
        )
        return

    stk = content[1].strip()
    bank = content[2].lower().strip()
    amount = content[3].strip() if len(content) > 3 else ""
    account_name = content[4].strip() if len(content) > 4 else ""
    add_info = content[5].strip() if len(content) > 5 else ""

    if not stk.isdigit():
        client.send(Message(text="🔢 Số tài khoản phải là số!"), thread_id=thread_id, thread_type=thread_type)
        return

    if bank not in BANK_LIST:
        suggestions = [b for b in BANK_LIST if bank in b]
        suggest_text = (
            "\n🔎 Có phải bạn muốn:\n" +
            "\n".join(f"👉 `{s}`" for s in suggestions[:3])
        ) if suggestions else ""
        client.send(
            Message(text=f"❌ Mã ngân hàng `{bank}` không hợp lệ.{suggest_text}"),
            thread_id=thread_id,
            thread_type=thread_type
        )
        return

    params = {
        "amount": amount,
        "addInfo": add_info,
        "accountName": account_name
    }
    query_string = urllib.parse.urlencode({k: v for k, v in params.items() if v})
    qr_url = f"https://img.vietqr.io/image/{bank}-{stk}-RegCr8p.png"
    if query_string:
        qr_url += f"?{query_string}"

    try:
        resp = requests.get(qr_url, timeout=10)
        if resp.status_code != 200 or not resp.content.startswith(b"\x89PNG"):
            client.send(Message(text="⚠️ Không thể tạo QR. Kiểm tra lại thông tin nhập vào!"), thread_id=thread_id, thread_type=thread_type)
            return

        with tempfile.NamedTemporaryFile(suffix=".png", delete=False) as tmp:
            tmp.write(resp.content)
            file_path = tmp.name

        info = (
            "✅ QR ĐÃ TẠO THÀNH CÔNG\n\n"
            f"🏦 Ngân hàng: {bank.upper()}\n"
            f"🔢 STK: {stk}\n"
            f"👤 Người nhận: {account_name or 'Không rõ'}\n"
            f"💵 Số tiền: {amount or 'Không có'}\n"
            f"📝 Nội dung: {add_info or 'Không có'}\n\n"
            "📲 Dùng app ngân hàng để quét mã QR và chuyển tiền!"
        )

        client.sendLocalImage(
            file_path,
            message=Message(text=info),
            thread_id=thread_id,
            thread_type=thread_type
        )
        os.remove(file_path)

    except Exception as e:
        client.send(
            Message(text=f"🚫 Lỗi tạo QR:\n```{e}```"),
            thread_id=thread_id,
            thread_type=thread_type
        )


def get_szl():
    return {
        'qrbank': handle_qrbank_command
    }