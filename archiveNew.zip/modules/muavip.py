import time
from zlapi.models import Message
import requests
import tempfile
import os

des = {
    'version': "1.0.4",
    'credits': "Hoàng Duy Tư",
    'description': "Lệnh Mua VIP"
}
def handle_muavip_command(message, message_object, thread_id, thread_type, author_id, client):
    # Thông tin thanh toán
    bank_code = "mbbank"
    stk = "444888365"
    chu_tk = "HOANG DUY TU"
    price = 40000
    price_text = "40.000 VNĐ / 1 tháng"
    nd_chuyen_khoan = f"muavip_{author_id}"

    # Tạo link QR
    qr_url = (
        f"https://img.vietqr.io/image/{bank_code}-{stk}-RegCr8p.png"
        f"?amount={price}&addInfo={nd_chuyen_khoan}&accountName={chu_tk.replace(' ', '+')}"
    )

    try:
        resp = requests.get(qr_url, timeout=10)
        if resp.status_code != 200 or not resp.content.startswith(b"\x89PNG"):
            client.send(
                Message(text="⚠️ Không thể tạo mã QR! Vui lòng thử lại sau."),
                thread_id=thread_id,
                thread_type=thread_type
            )
            return

        with tempfile.NamedTemporaryFile(suffix=".png", delete=False) as tmp:
            tmp.write(resp.content)
            file_path = tmp.name

        caption = f"""🌟 THÔNG TIN MUA VIP 🌟
━━━━━━━━━━━━━━━━━━━━
🏦 Ngân hàng: {bank_code.upper()}
💳 STK: {stk}
👑 Chủ tài khoản: {chu_tk}
💰 Số tiền: {price_text}
📝 Nội dung CK: {nd_chuyen_khoan}
━━━━━━━━━━━━━━━━━━━━
⚠️ Lưu ý: Chuyển đúng nội dung và gửi ảnh biên lai cho admin để được kích hoạt VIP siêu tốc!
📩 Liên hệ Admin Trong Nhóm: https://zalo.me/g/bprmyn080
"""

        client.sendLocalImage(
            file_path,
            message=Message(text=caption),
            thread_id=thread_id,
            thread_type=thread_type
        )

        os.remove(file_path)

    except Exception as e:
        client.send(
            Message(text=f"🚫 Đã xảy ra lỗi khi tạo QR:\n```{e}```"),
            thread_id=thread_id,
            thread_type=thread_type
        )

def get_szl():
    return {
        'muavip': handle_muavip_command
    }