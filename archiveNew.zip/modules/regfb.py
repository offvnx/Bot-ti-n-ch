from zlapi.models import Message
import requests
import hashlib
import random
import time
from datetime import datetime
import urllib3

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

des = {
    'version': "1.0.1",
    'credits': "Hoàng Duy Tư",
    'description': "Reg acc Facebook cổ, không dùng HTML"
}

app = {
    'api_key': '882a8490361da98702bf97a021ddc14d',
    'secret': '62f8ce9f74b12f84c123cc23437a4a32',
}

email_prefix = ['gmail.com', 'hotmail.com', 'yahoo.com', 'outlook.com']

def generate_random_account():
    random_birth_day = datetime.strftime(datetime.fromtimestamp(random.randint(
        int(time.mktime(datetime.strptime('1980-01-01', '%Y-%m-%d').timetuple())),
        int(time.mktime(datetime.strptime('1995-12-30', '%Y-%m-%d').timetuple()))
    )), '%Y-%m-%d')

    names = {
        'first': ['JAMES', 'JOHN', 'ROBERT', 'MICHAEL', 'WILLIAM'],
        'last': ['SMITH', 'JOHNSON', 'WILLIAMS', 'BROWN', 'JONES'],
        'mid': ['Alex', 'Anthony', 'Charles', 'David', 'Edward']
    }

    first = random.choice(names['first'])
    last = f"{random.choice(names['mid'])} {random.choice(names['last'])}"
    full_name = f"{first} {last}"
    password = f'HelloReg{random.randint(100000,999999)}!@#'
    hash_ = hashlib.md5(str(time.time()).encode()).hexdigest()
    reg_id = f"{hash_[0:8]}-{hash_[8:12]}-{hash_[12:16]}-{hash_[16:20]}-{hash_[20:32]}"
    email = f"{full_name.replace(' ', '').lower()}{hash_[0:6]}@{random.choice(email_prefix)}"
    gender = 'M' if random.randint(0, 1) == 0 else 'F'

    req = {
        'api_key': app['api_key'],
        'attempt_login': True,
        'birthday': random_birth_day,
        'client_country_code': 'EN',
        'fb_api_caller_class': 'com.facebook.registration.protocol.RegisterAccountMethod',
        'fb_api_req_friendly_name': 'registerAccount',
        'firstname': first,
        'format': 'json',
        'gender': gender,
        'lastname': last,
        'email': email,
        'locale': 'en_US',
        'method': 'user.register',
        'password': password,
        'reg_instance': reg_id,
        'return_multiple_errors': True
    }

    sig_raw = ''.join([f'{k}={v}' for k, v in sorted(req.items())])
    sig = hashlib.md5((sig_raw + app['secret']).encode()).hexdigest()
    req['sig'] = sig

    headers = {
        'User-Agent': '[FBAN/FB4A;FBAV/35.0.0.48.273;FBPN/com.facebook.katana;FBDV/Nexus 7;FBSV/4.1.1;]'
    }

    try:
        response = requests.post('https://b-api.facebook.com/method/user.register', data=req, headers=headers, verify=False, timeout=15)
        data = response.json()
        uid = data.get('session_info', {}).get('uid')
        token = data.get('session_info', {}).get('access_token')
        error_code = data.get('error_code')
        error_msg = data.get('error_msg')

        if uid and token:
            return {
                "dob": random_birth_day,
                "name": full_name,
                "email": email,
                "password": password,
                "uid": uid,
                "token": token
            }, None
        else:
            return None, f"Lỗi: {error_code} - {error_msg}" if error_code else "Lỗi không xác định"
    except Exception as e:
        return None, str(e)

def handle_regfb_command(message, message_object, thread_id, thread_type, author_id, client):
    if not hasattr(message_object, 'content') or not isinstance(message_object.content, str):
        return
    if not message_object.content.startswith('/regfb'):
        return

    client.send(Message(text="⏳ Đang tạo tài khoản Facebook..."), thread_id, thread_type)
    data, error = generate_random_account()

    if error:
        client.send(Message(text=f"❌ {error}"), thread_id, thread_type)
        return

    result = (
        f"TẠO TÀI KHOẢN FACEBOOK THÀNH CÔNG\n"
        f"──────────────\n"
        f"Họ tên: {data['name']}\n"
        f"Email: {data['email']}\n"
        f"Mật khẩu: {data['password']}\n"
        f"UID: {data['uid']}\n"
        f"Token: {data['token']}\n"
        f"Ngày sinh: {data['dob']}\n"
        f"──────────────\n"
        f"Lưu ý: Token này có thể hết hạn sớm, hãy sử dụng ngay!"
    )

    client.send(Message(text=result), thread_id, thread_type)

def get_szl():
    return {
        'regfb': handle_regfb_command
    }