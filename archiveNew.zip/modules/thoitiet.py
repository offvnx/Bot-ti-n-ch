from zlapi.models import Message
import requests
des = {
    'version': "1.0.0",
    'credits': "Hoàng Duy Tư",
    'description': "Thời tiết"
}
# Hàm định dạng tin nhắn thời tiết
def format_weather(data):
    try:
        msg = f"🌦 {data['city_display']} | {data['description']}\n"
        msg += f"🌡 Nhiệt độ: {data['temperature']}°C (cảm giác như {data['feels_like']}°C)\n"
        msg += f"⬆️ Max: {data['temp_max']}°C\n"
        msg += f"⬇️ Min: {data['temp_min']}°C\n"
        msg += f"💧 Độ ẩm: {data['humidity']}%\n"
        msg += f"🍃 Áp suất: {data['pressure']} hPa\n"
        msg += f"☁️ Mây: {data['clouds']}%\n"
        msg += f"💨 Gió: {data['wind_speed']} m/s, hướng {data['wind_deg']}°\n"
        msg += f"👁️ Tầm nhìn: {data['visibility_km']} km\n"
        if data.get('rain_1h'):
            msg += f"🌧️ Mưa (1h): {data['rain_1h']} mm\n"
        if data.get('snow_1h'):
            msg += f"❄️ Tuyết (1h): {data['snow_1h']} mm\n"
        if data.get('aqi'):
            msg += f"☄️ AQI: {data['aqi']}/5\n"
        if data.get('uv_index'):
            msg += f"☀️ UV: {data['uv_index']} ({data.get('uv_level', '')})\n"
        msg += f"🌅 Mặt trời mọc: {data['sunrise']}\n"
        msg += f"🌇 Mặt trời lặn: {data['sunset']}\n"
        msg += f"🗺 Bản đồ: {data['location_url']}"
        return msg
    except Exception as e:
        return f"❌ Lỗi định dạng dữ liệu: {e}"

# Handler lệnh /thoitiet cho bot Zalo
def handle_weather_command(message, message_object, thread_id, thread_type, author_id, client):
    if not hasattr(message_object, 'content') or not isinstance(message_object.content, str):
        return
    if not message_object.content.startswith('/thoitiet'):
        return

    args = message.strip().split(maxsplit=1)
    if len(args) < 2:
        client.send(Message(text="📝 Dùng: /thoitiet [tên thành phố]"), thread_id, thread_type)
        return

    city = args[1].strip()
    try:
        url = f"https://offvnx.x10.bz/api/thoitiet.php?city={city}"
        res = requests.get(url)
        if res.status_code != 200:
            client.send(Message(text="❌ Không thể truy cập API thời tiết."), thread_id, thread_type)
            return

        data = res.json()
        if not data or "city" not in data:
            client.send(Message(text=f"❌ Không tìm thấy thông tin thời tiết cho '{city}'."), thread_id, thread_type)
            return

        msg = format_weather(data)
        client.send(Message(text=msg), thread_id, thread_type)

        # Nếu có location_url thì gửi vị trí
        if "location_url" in data:
            try:
                coords = data["location_url"].split("q=")[-1].split(",")
                lat, lon = float(coords[0]), float(coords[1])
                client.sendLocation(latitude=lat, longitude=lon, thread_id=thread_id, thread_type=thread_type)
            except:
                pass

    except Exception as e:
        client.send(Message(text=f"❌ Lỗi xử lý dữ liệu: {e}"), thread_id, thread_type)

# Đăng ký vào danh sách lệnh
def get_szl():
    return {
        'thoitiet': handle_weather_command
    }