from zlapi.models import Message
import requests

des = {
    'version': "1.0.0",
    'credits': "Hoàng Duy Tư",
    'description': "Gửi câu hỏi và nhận câu trả lời từ GPT"
}

GPT_API_URL = "https://gpt-3-5.apis-bj-devs.workers.dev/?prompt="

def handle_ask_command(message, message_object, thread_id, thread_type, author_id, client):
    if not hasattr(message_object, 'content') or not isinstance(message_object.content, str):
        return

    if not message_object.content.startswith('/ask'):
        return

    query = message_object.content[len('/ask'):].strip()

    if not query:
        client.send(
            Message(text="⚠️ Vui lòng nhập nội dung sau lệnh /ask."),
            thread_id=thread_id,
            thread_type=thread_type
        )
        return

    try:
        res = requests.get(GPT_API_URL + requests.utils.quote(query), timeout=10)
        if res.status_code == 200:
            data = res.json()
            reply = data.get('reply') or data.get('text') or '🤖 Không có phản hồi từ GPT.'
            response_text = f"🤖 GPT trả lời:\n\n💬 {reply}"
        else:
            response_text = "🚫 API không phản hồi hợp lệ."
    except Exception as e:
        response_text = f"❌ Lỗi khi xử lý: {str(e)}"

    client.send(
        Message(text=response_text),
        thread_id=thread_id,
        thread_type=thread_type
    )

def get_szl():
    return {
        'ask': handle_ask_command
    }