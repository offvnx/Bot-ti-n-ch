from zlapi.models import Message

des = {
    'version': "1.0.2",
    'credits': "Hoàng Duy Tư",
    'description': "Gửi danh sách source bot Telegram"
}

def handle_scrtelegram_command(message, message_object, thread_id, thread_type, author_id, client):
    if not hasattr(message_object, 'content') or not isinstance(message_object.content, str):
        return

    if not message_object.content.startswith('/scrtelegram'):
        return

    content = (
        "📦 TỔNG FULL SOURCE BOT TELEGRAM\n\n"
        "• File BOT CHECK XU TRAODOISUB\n"
        "🔗 https://link4m.com/LOX7x\n\n"
        "• File BOT TÀI XỈU Telegram\n"
        "🔗 https://link4m.com/8GcLR\n\n"
        "• File Cày Xu TDS BOT Telegram\n"
        "🔗 https://link4m.com/dyx388\n\n"
        "• File SPAM SMS CALL BOT Telegram\n"
        "🔗 https://link4m.com/IODOo5B\n\n"
        "• File SPAM SMS CALL BOT Telegram VIP\n"
        "🔗 https://link4m.com/tH1Fpj\n\n"
        "• File SPAM SMS CALL BOT Telegram Ngon\n"
        "🔗 https://link4m.com/6eePysOT\n\n"
        "• File Nhiều Chức Năng BOT Telegram\n"
        "🔗 https://link4m.com/bPdOwdJL\n\n"
        "• File Kết Quả Xổ Số Hôm Nay BOT TELEGRAM\n"
        "🔗 https://link4m.com/CRFkK1u\n\n"
        "• File Kiểm Tra Thời Tiết Hôm Nay BOT TELEGRAM\n"
        "🔗 https://link4m.com/2giuG\n\n"
        "• File Check 12 Con Giáp BOT TELEGRAM\n"
        "🔗 https://link4m.com/usu3rY\n\n"
        "• File Check 12 Cung Hoàng Đạo BOT TELEGRAM\n"
        "🔗 https://link4m.com/yh1H0V5\n\n"
        "• File Video Sex Ngẫu Nhiên BOT TELEGRAM\n"
        "🔗 https://link4m.com/bA5sZxDM\n\n"
        "• File Check Biển Số Xe Vi Phạm BOT TELEGRAM\n"
        "🔗 https://link4m.com/3fx46I\n\n"
        "📊 Tổng số liên kết: 13"
    )

    client.send(
        Message(text=content),
        thread_id=thread_id,
        thread_type=thread_type
    )

def get_szl():
    return {
        'scrtelegram': handle_scrtelegram_command
    }