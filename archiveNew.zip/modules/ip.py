from zlapi.models import Message
import requests
import tempfile
import os

des = {
    'version': "1.0.0",
    'credits': "Hoàng Duy Tư",
    'description': "Tra cứu thông tin địa chỉ IP"
}

def get_ip_info(ip):
    url = f"https://ip-info.bjcoderx.workers.dev/?ip={requests.utils.quote(ip)}"
    try:
        response = requests.get(url, timeout=10)
        return response.json()
    except Exception:
        return None

def handle_ip_command(message, message_object, thread_id, thread_type, author_id, client):
    if not hasattr(message_object, 'content') or not isinstance(message_object.content, str):
        return

    if not message_object.content.startswith('/ip'):
        return

    args = message.strip().split(' ', 1)
    if len(args) < 2:
        client.send(
            Message(text="❌ Vui lòng nhập địa chỉ IP.\nVí dụ: /ip 14.191.136.129"),
            thread_id=thread_id,
            thread_type=thread_type
        )
        return

    ip = args[1].strip()
    data = get_ip_info(ip)

    if not data or "ip" not in data:
        client.send(
            Message(text="⚠️ Không thể lấy thông tin IP. Vui lòng thử lại sau."),
            thread_id=thread_id,
            thread_type=thread_type
        )
        return

    tz = data.get('time_zone', {})
    currency = data.get('currency', {})

    info = f"""
📡 THÔNG TIN IP
──────────────
🌐 IP: {data['ip']}
🗺 Châu lục: {data['continent_name']} ({data['continent_code']})
🏳 Quốc gia: {data['country_name']} ({data['country_code2']}) {data['country_emoji']}
📝 Tên chính thức: {data['country_name_official']}
🏛 Thủ đô: {data['country_capital']}
🏙 Thành phố: {data['city']}
📍 Bang/Tỉnh: {data['state_prov']}
🏞 Quận/Huyện: {data['district']}
🏷 Mã ZIP: {data['zipcode']}
🧭 Vĩ độ: {data['latitude']}
🧭 Kinh độ: {data['longitude']}
📌 Geo ID: {data['geoname_id']}
📞 Mã gọi quốc gia: {data['calling_code']}
🔤 Ngôn ngữ: {data['languages']}
🌐 Miền quốc gia: {data['country_tld']}

🕐 Múi giờ: {tz.get('name', '')} (UTC+{tz.get('offset', '')})
🕓 Giờ hiện tại: {tz.get('current_time', '')}

💰 Tiền tệ: {currency.get('name', '')} ({currency.get('symbol', '')})

📡 ISP: {data['isp']}
🏢 Tổ chức: {data['organization']}
──────────────
""".strip()

    flag_url = data.get('country_flag')
    if flag_url:
        try:
            img_data = requests.get(flag_url, timeout=10).content
            with tempfile.NamedTemporaryFile(suffix=".png", delete=False) as tmp:
                tmp.write(img_data)
                file_path = tmp.name

            client.sendLocalImage(
                file_path,
                message=Message(text=info),
                thread_id=thread_id,
                thread_type=thread_type
            )
            os.remove(file_path)
        except Exception:
            # Nếu lỗi tải ảnh thì fallback gửi text
            client.send(
                Message(text=info),
                thread_id=thread_id,
                thread_type=thread_type
            )
    else:
        # Không có ảnh quốc kỳ thì gửi text bình thường
        client.send(
            Message(text=info),
            thread_id=thread_id,
            thread_type=thread_type
        )


def get_szl():
    return {
        'ip': handle_ip_command
    }