from zlapi.models import Message
from datetime import datetime
import threading
import requests
import os
import colorsys
import random
import json
from io import BytesIO
from PIL import Image, ImageDraw, ImageFont, ImageEnhance, ImageFilter
import qrcode

# Metadata
des = {
    'version': "1.0.3",
    'credits': "Hoàng Duy Tư",
    'description': "Kiểm tra thông tin zalo"
}

def read_settings():
    if not os.path.exists("settings.json"):
        return {"banned_users": []}
    with open("settings.json", "r", encoding="utf-8") as f:
        return json.load(f)

# Màu 4 sắc: xanh lá - đỏ - vàng - cam
rainbow_colors = [
    (0, 255, 0),      # Xanh lá
]

# Màu xanh biếc cho phần thông tin user
info_text_color = (255, 215, 0)

def handle_infouser_image(bot, message_object, thread_id, thread_type, author_id):
    def send_user_info_image():
        try:
            settings = read_settings()
            banned_users = settings.get("banned_users", [])
            if author_id in banned_users:
                return

            mentions = message_object.mentions
            target_id = mentions[0]['uid'] if mentions else author_id

            user = bot.fetchUserInfo(target_id).changed_profiles.get(target_id)
            if not user:
                bot.send(Message(text="❌ Không thể lấy thông tin người dùng."), thread_id=thread_id, thread_type=thread_type)
                return

            avatar_url = user.avatar
            background_url = user.cover
            user_name = user.zaloName or "Không rõ"

            if not avatar_url or not background_url:
                bot.send(Message(text="❌ Người dùng không có ảnh đại diện hoặc ảnh nền."), thread_id=thread_id, thread_type=thread_type)
                return

            background_img = Image.open(BytesIO(requests.get(background_url).content)).convert("RGBA")
            background_img = background_img.resize((1000, 485), Image.LANCZOS)
            background_img = ImageEnhance.Brightness(background_img).enhance(0.3)
            background_img = background_img.filter(ImageFilter.GaussianBlur(radius=7))

            avatar_img = Image.open(BytesIO(requests.get(avatar_url).content)).convert("RGBA")
            avatar_img = avatar_img.resize((140, 140), Image.LANCZOS)
            mask = Image.new("L", avatar_img.size, 0)
            ImageDraw.Draw(mask).ellipse((0, 0, 140, 140), fill=255)

            border_thickness = 10
            total_size = (140 + 2 * border_thickness, 140 + 2 * border_thickness)
            border_img = Image.new("RGBA", total_size, (0, 0, 0, 0))
            draw_border = ImageDraw.Draw(border_img)
            for angle in range(0, 360, 3):
                hue = angle / 360.0
                r, g, b = [int(x * 255) for x in colorsys.hsv_to_rgb(hue, 1, 1)]
                draw_border.arc([0, 0, total_size[0] - 1, total_size[1] - 1],
                                start=angle, end=angle + 3,
                                fill=(r, g, b), width=border_thickness)
            border_img.paste(avatar_img, (border_thickness, border_thickness), mask)
            avatar_pos = (60, 60)
            background_img.paste(border_img, avatar_pos, border_img)

            draw = ImageDraw.Draw(background_img)
            font_path = "BeVietnamPro-Bold.ttf"
            emoji_font_path = "emoji.ttf"
            font = ImageFont.truetype(font_path, 36)
            emoji_font = ImageFont.truetype(emoji_font_path, 30)

            # QR Zalo
            qr_data = f"https://zalo.me/{user.userId}"
            qr = qrcode.make(qr_data)
            qr = qr.resize((100, 100))
            qr_pos = (background_img.width - 110, 10)
            background_img.paste(qr, qr_pos)

            # Tiêu đề 4 màu tuần hoàn
            title_text = "THÔNG TIN NGƯỜI DÙNG"
            title_font = ImageFont.truetype(font_path, 50)
            title_x = (1000 - draw.textbbox((0, 0), title_text, font=title_font)[2]) // 2
            title_y = 20
            current_x_title = title_x
            for i, char in enumerate(title_text):
                color = rainbow_colors[i % len(rainbow_colors)]
                draw.text((current_x_title, title_y), char, font=title_font, fill=color)
                current_x_title += draw.textbbox((0, 0), char, font=title_font)[2]

            # Tên người dùng
            name_font = ImageFont.truetype(font_path, 28)
            name_x = avatar_pos[0] + (total_size[0] - draw.textbbox((0, 0), user_name, font=name_font)[2]) // 2
            name_y = avatar_pos[1] + total_size[1] + 10
            draw.text((name_x, name_y), user_name, fill=(255, 255, 255), font=name_font)

            # Thông tin người dùng đổi màu xanh biếc
            user_info_text = (
                f"💡 UID: {user.userId}\n"
                f"🎂 Sinh nhật: {datetime.fromtimestamp(user.dob).strftime('%d/%m/%Y') if user.dob else 'Ẩn'}\n"
                f"🚻 Giới tính: {'Nam' if user.gender == 0 else 'Nữ' if user.gender == 1 else 'Không rõ'}\n"
                f"💼 Business: {'Có' if user.bizPkg.label else 'Không'}\n"
                f"⏳ Ngày Tạo: {datetime.fromtimestamp(user.createdTs).strftime('%d/%m/%Y') if user.createdTs else 'Không rõ'}\n"
                f"⏰ Hoạt động: {datetime.fromtimestamp(user.lastActionTime / 1000).strftime('%d/%m/%Y %H:%M:%S') if user.lastActionTime else 'Không rõ'}\n"
            )

            info_font = ImageFont.truetype(font_path, 28)
            info_x = 300
            info_y = 130
            for line in user_info_text.split("\n"):
                current_x = info_x
                for char in line:
                    if char in "💡🎂🚻💼⏳⏰":
                        font_to_use = emoji_font
                        fill_color = (255, 0, 0)  # Vàng cho icon
                    elif char == ":":
                        font_to_use = info_font
                        fill_color = (255, 69, 0)   # Đỏ cam cho dấu hai chấm
                    else:
                        font_to_use = info_font
                        fill_color = info_text_color  # Xanh biếc cho chữ thông tin
                    draw.text((current_x, info_y), char, font=font_to_use, fill=fill_color)
                    current_x += draw.textbbox((0, 0), char, font=font_to_use)[2]
                info_y += 38

            draw.line([(50, 360), (950, 360)], fill=(255, 255, 255), width=2)

            # Bio 4 màu tuần hoàn
            bio_text = user.status if user.status else 'Không có thông tin.'
            bio_font_size = 28
            bio_font = ImageFont.truetype(font_path, bio_font_size)
            max_width = 900
            while draw.textbbox((0, 0), bio_text, font=bio_font)[2] > max_width and bio_font_size > 10:
                bio_font_size -= 2
                bio_font = ImageFont.truetype(font_path, bio_font_size)

            bio_x = 70
            bio_y = 380
            current_x_bio = bio_x
            for i, char in enumerate(bio_text):
                color = rainbow_colors[i % len(rainbow_colors)]
                draw.text((current_x_bio, bio_y), char, font=bio_font, fill=color)
                current_x_bio += draw.textbbox((0, 0), char, font=bio_font)[2]

            image_path = "user_info_image.png"
            background_img.save(image_path)
            bot.sendLocalImage(
                image_path,
                thread_id=thread_id,
                thread_type=thread_type,
                message=Message(text=""),
                height=485,
                width=1000,
                ttl=0
            )

        except Exception as e:
            bot.send(Message(text=f"❌ Đã xảy ra lỗi: {e}"), thread_id=thread_id, thread_type=thread_type)

    threading.Thread(target=send_user_info_image).start()


def handle_infouser_command(message, message_object, thread_id, thread_type, author_id, client):
    handle_infouser_image(client, message_object, thread_id, thread_type, author_id)


def get_szl():
    return {
        'info': handle_infouser_command
    }