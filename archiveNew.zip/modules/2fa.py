from zlapi.models import Message
import requests
import re

des = {
    'version': "1.0.0",
    'credits': "Hoàng Duy Tư",
    'description': "Tạo mã 2FA từ chuỗi Base32"
}

def handle_2fa_command(message, message_object, thread_id, thread_type, author_id, client):
    if not hasattr(message_object, 'content') or not isinstance(message_object.content, str):
        return

    if not message_object.content.startswith('/2fa'):
        return

    parts = message.strip().split()
    if len(parts) < 2:
        client.send(
            Message(text="⚠️ Vui lòng nhập mã sau lệnh /2fa\n\nVí dụ:\n/2fa 242RIHRGMWYHZ76GDDEZSP3XKK5TUJSQ"),
            thread_id=thread_id,
            thread_type=thread_type
        )
        return

    ma2fa = parts[1].strip().upper()

    # Kiểm tra mã hợp lệ theo chuẩn Base32 (chỉ A-Z và 2-7), 32 ký tự
    if not re.fullmatch(r'[A-Z2-7]{32}', ma2fa):
        client.send(
            Message(text="❌ Mã 2FA không hợp lệ!\n\nMã phải gồm 32 ký tự chữ in hoa và số, không dấu cách hoặc ký tự đặc biệt.\n\nVí dụ hợp lệ:\n/2fa 242RIHRGMWYHZ76GDDEZSP3XKK5TUJSQ"),
            thread_id=thread_id,
            thread_type=thread_type
        )
        return

    try:
        response = requests.get(f"https://2fa.live/tok/{ma2fa}", timeout=5)
        response.raise_for_status()
        res = response.json()
        code = res.get("token")

        if code and code.isdigit() and len(code) == 6:
            msg = (
                f"🔐 Bạn Đã Nhập Là:  {ma2fa}\n\n🔑 Mã Là: {code}\n✅ Mã hợp lệ!\n\n🕒 Mỗi mã có hiệu lực khoảng 30 giây."
            )
        else:
            msg = (
                f"❌ Không thể tạo mã 2FA từ chuỗi bạn cung cấp.\n"
                f"Vui lòng kiểm tra lại chuỗi: {ma2fa}"
            )
    except requests.exceptions.Timeout:
        msg = "⏰ Máy chủ quá tải hoặc mất kết nối, vui lòng thử lại sau vài giây."
    except requests.exceptions.RequestException:
        msg = "❌ Có lỗi khi kết nối đến máy chủ 2FA. Vui lòng thử lại sau."

    client.send(
        Message(text=msg),
        thread_id=thread_id,
        thread_type=thread_type
    )


def get_szl():
    return {
        '2fa': handle_2fa_command,
        # các lệnh khác nếu có
    }