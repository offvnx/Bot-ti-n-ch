from zlapi.models import Message
import requests
import os
des = {
    'version': "1.0.3",
    'credits': "Hoàng Duy Tư",
    'description': "Kiểm tra thông tin tiktok"
}
def handle_tt_command(message, message_object, thread_id, thread_type, author_id, client):
    content = message.strip().split()

    if len(content) < 2:
        client.send(Message(text="⚠️ Vui lòng nhập username TikTok. Ví dụ: /tt duonghungcasi"), thread_id=thread_id, thread_type=thread_type)
        return

    username = content[1]
    api_url = f"https://offvnx.x10.bz/api/tt.php?input={username}&key=offvnx"

    try:
        res = requests.get(api_url, timeout=10)
        data = res.json()

        if not data.get("success"):
            client.send(Message(text="❌ Không thể lấy thông tin người dùng. Vui lòng kiểm tra lại username."), thread_id=thread_id, thread_type=thread_type)
            return

        user_info = data['data']['userInfo']['user']
        stats = data['data']['userInfo']['statsV2']

        is_verified = "Đã xác minh ✅" if user_info.get('verified') else "Chưa xác minh ❌"
        account_status = "Công Khai ✅" if not user_info.get('privateAccount') else "Riêng Tư ❌"
        has_playlist = "Có danh sách phát ✅" if user_info.get('profileTab', {}).get('showPlayListTab') else "Không có danh sách phát ❌"
        following_visibility = "Danh sách following đã bị ẩn ❌" if user_info.get('followingVisibility') == 2 else "Danh sách following hiển thị ✅"
        commerce_status = f"Người dùng thương mại 🛒 ({user_info.get('commerceUserInfo', {}).get('category', 'Chưa rõ')})" if user_info.get('commerceUserInfo', {}).get('commerceUser') else "Không phải tài khoản thương mại ❌"
        download_status = "Cho phép tải video ✅" if user_info.get('downloadSetting') == 0 else "Không cho tải video ❌"
        seller_status = "Người bán TikTok Shop 🛍️" if user_info.get('ttSeller') else "Không phải người bán ❌"
        org_status = "Tổ chức 🏢" if user_info.get('isOrganization') else "Cá nhân 👤"
        live_status = "Đang Livestream 🔴" if user_info.get('roomId') else "Không livestream ❌"
        comment_setting = ["Mọi người", "Bạn bè", "Không ai"][user_info.get('commentSetting', 0)]
        duet_setting = ["Mọi người", "Bạn bè", "Không ai"][user_info.get('duetSetting', 0)]
        stitch_setting = ["Mọi người", "Bạn bè", "Không ai"][user_info.get('stitchSetting', 0)]

        result = f"""
╭─────────────⭓
│ ‎𝗡𝗮𝗺𝗲: {user_info['nickname']}
│ 𝗜𝗗: {user_info['id']}
│ 𝗨𝘀𝗲𝗿𝗻𝗮𝗺𝗲: {user_info['uniqueId']}
│ 𝗟𝗶𝗻𝗸: https://www.tiktok.com/@{user_info['uniqueId']}
│ 𝗩𝗲𝗿𝗶𝗳𝗶𝗲𝗱: {is_verified}
│ 𝗦𝘁𝗮𝘁𝘂𝘀:
│ | -> {account_status}
│ | -> {has_playlist}
│ | -> {following_visibility}
│ | -> {live_status}
│ | -> {download_status}
│ | -> Bình luận: {comment_setting} 💬
│ | -> Duet: {duet_setting} 🎤
│ | -> Stitch: {stitch_setting} ✂️
│ 𝗖𝗼𝗺𝗺𝗲𝗿𝗰𝗲: {commerce_status}
│ 𝗦𝗲𝗹𝗹: {seller_status}
│ 𝗔𝗰𝗰𝗼𝘂𝗻𝘁: {org_status}
│ 𝗕𝗶𝗼: {user_info.get('signature', 'Không có')}
│ 𝗙𝗼𝗹𝗹𝗼𝘄𝗲𝗿𝘀: {int(stats.get('followerCount', 0)):,} Follower
│ 𝗙𝗼𝗹𝗹𝗼𝘄𝗶𝗻𝗴: {int(stats.get('followingCount', 0)):,} Đang Follow
│ 𝗙𝗿𝗶𝗲𝗻𝗱𝘀: {int(stats.get('friendCount', 0)):,} Bạn Bè
│ 𝗟𝗶𝗸𝗲𝘀: {int(stats.get('heartCount', 0)):,} Thích
│ 𝗩𝗶𝗱𝗲𝗼𝘀: {int(stats.get('videoCount', 0)):,} Video
├─────────────⭔
│ 𝗡𝗮𝗺𝗲 𝗨𝗽𝗱𝗮𝘁𝗲: {user_info.get('nickNameModifyTime', 'Không rõ')}
│ 𝗖𝗿𝗲𝗮𝘁𝗲𝗱 𝗧𝗶𝗺𝗲: {user_info.get('createTime', 'Không rõ')}
│ 𝗟𝗮𝗻𝗴𝘂𝗮𝗴𝗲: {user_info.get('language', 'Không rõ')}
╰─────────────⭓
""".strip()

        avatar_url = user_info.get("avatarLarger")
        if avatar_url and avatar_url.startswith("http"):
            img_data = requests.get(avatar_url, timeout=5).content
            path = "tt_avatar.jpg"
            with open(path, 'wb') as f:
                f.write(img_data)
            client.sendLocalImage(path, message=Message(text=result), thread_id=thread_id, thread_type=thread_type)
            os.remove(path)
        else:
            client.send(Message(text=result), thread_id=thread_id, thread_type=thread_type)

    except Exception as e:
        client.send(Message(text="🚫 Đã xảy ra lỗi khi lấy thông tin TikTok."), thread_id=thread_id, thread_type=thread_type)


def get_szl():
    return {
        'tt': handle_tt_command
    }