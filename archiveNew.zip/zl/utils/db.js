const path = require('path');
const fs = require('fs');
const sqlite3 = require('sqlite3').verbose();
const logger = require('./logger');

const dbPath = path.join(__dirname, '..', 'data', 'sqlite.db');

// Tạo thư mục chứa DB nếu chưa tồn tại
const dbDir = path.dirname(dbPath);
if (!fs.existsSync(dbDir)) fs.mkdirSync(dbDir, { recursive: true });

// Kết nối đến CSDL
const db = new sqlite3.Database(dbPath, (err) => {
  if (err) {
    console.error('❌ Không thể kết nối database:', err.message);
  } else {
    logger.log("✅ Đã kết nối database sqlite", "info");

    db.run(`CREATE TABLE IF NOT EXISTS Threads (
      threadId TEXT PRIMARY KEY,
      data TEXT
    )`);

    db.run(`CREATE TABLE IF NOT EXISTS Users (
      userId TEXT PRIMARY KEY,
      data TEXT
    )`);

    db.run(`CREATE TABLE IF NOT EXISTS Currencies (
      userId TEXT PRIMARY KEY,
      data TEXT
    )`);
  }
});

function getData(table, idField, id, callback) {
  const query = `SELECT * FROM ${table} WHERE ${idField} = ?`;
  db.get(query, [id], (err, row) => {
    if (err) {
      console.error("❌ Lỗi khi truy vấn dữ liệu:", err.message);
      return callback(null);
    }
    if (!row) return callback(null);

    try {
      const parsed = JSON.parse(row.data);
      callback(parsed);
    } catch (e) {
      console.error("❌ Lỗi khi parse JSON:", e);
      callback(null);
    }
  });
}

function setData(table, idField, id, data) {
  const stringData = JSON.stringify(data);
  const query = `INSERT OR REPLACE INTO ${table} (${idField}, data) VALUES (?, ?)`;
  db.run(query, [id, stringData], (err) => {
    if (err) {
      console.error("❌ Lỗi khi lưu dữ liệu:", err.message);
    }
  });
}

module.exports = {
  getData,
  setData
};